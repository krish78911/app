$('#glass1').on('click', function () {
    isRedOrBlue = "glass1";
    // For identification, I'm adding border
    
     //$('#frame3 .glass').empty();  
//$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').empty();
    
     $("#frame3 .glass").css({
   'background-image' : 'url("images/largeglass/G1.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 .ovalglass").css({
   'background-image' : 'url("images/ovalglass/G1.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #oval-f1").css({
   'background-image' : 'url("images/ovalroundtop/G1.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $('#frame3 #tdglass1tri, #frame3 #tdglass2tri').css({
   'background-image' : 'url("images/doorglass/G1.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').css({
   'background-image' : 'url("images/largeglass/G1.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $("#frame3 #tdglassD5 .glass").css({
   'background-image': 'url("images/doorglass5/G1.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD8 .glass").css({
   'background-image': 'url("images/doorglass8/G1.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD9 div.glass").css({
   'background-image': 'url("images/doorglass9/G1.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD3 div.glass").css({
   'background-image': 'url("images/ovalroundtop/G1.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #doorglassdefault2").css({
   'background-image': 'url("images/ovalroundtop/G1.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #table1 .glass").css({
   'background-image': 'url("images/smalldoorglass/G1.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
    $("#frame3 #table3 .glass, #frame3 #doorglassdefault1").css({
   'background-image': 'url("images/doorcenter/G1.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
});

$('#glass2').on('click', function () {
    isRedOrBlue = "glass2";
     //$('#frame3 .glass').empty();
//$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').empty();
    
     $("#frame3 .glass").css({
   'background-image' : 'url("images/largeglass/G2.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 .ovalglass").css({
   'background-image' : 'url("images/ovalglass/G2.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #oval-f1").css({
   'background-image' : 'url("images/ovalroundtop/G2.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
    $('#frame3 #tdglass1tri, #frame3 #tdglass2tri').css({
   'background-image' : 'url("images/doorglass/G2.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').css({
   'background-image' : 'url("images/largeglass/G2.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $("#frame3 #tdglassD5 .glass").css({
   'background-image': 'url("images/doorglass5/G2.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD8 .glass").css({
   'background-image': 'url("images/doorglass8/G2.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD9 div.glass").css({
   'background-image': 'url("images/doorglass9/G2.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #tdglassD3 div.glass").css({
   'background-image': 'url("images/ovalroundtop/G2.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #doorglassdefault2").css({
   'background-image': 'url("images/ovalroundtop/G2.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #table1 .glass").css({
   'background-image': 'url("images/smalldoorglass/G2.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
    $("#frame3 #table3 .glass, #frame3 #doorglassdefault1").css({
   'background-image': 'url("images/doorcenter/G2.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
});

$('#glass3').on('click', function () {
    isRedOrBlue = "glass3";
    
     //$('#frame3 .glass').empty();
//$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').empty();
    
     $("#frame3 .glass").css({
   'background-image' : 'url("images/largeglass/G3.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 .ovalglass").css({
   'background-image' : 'url("images/ovalglass/G3.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #oval-f1").css({
   'background-image' : 'url("images/ovalroundtop/G3.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $('#frame3 #tdglass1tri, #frame3 #tdglass2tri').css({
   'background-image' : 'url("images/doorglass/G3.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').css({
   'background-image' : 'url("images/largeglass/G3.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $("#frame3 #tdglassD5 .glass").css({
   'background-image': 'url("images/doorglass5/G3.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD8 .glass").css({
   'background-image': 'url("images/doorglass8/G3.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD9 div.glass").css({
   'background-image': 'url("images/doorglass9/G3.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #tdglassD3 div.glass").css({
   'background-image': 'url("images/ovalroundtop/G3.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #doorglassdefault2").css({
   'background-image': 'url("images/ovalroundtop/G3.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #table1 .glass").css({
   'background-image': 'url("images/smalldoorglass/G3.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
    $("#frame3 #table3 .glass, #frame3 #doorglassdefault1").css({
   'background-image': 'url("images/doorcenter/G3.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
});

$('#glass4').on('click', function () {
    isRedOrBlue = "glass4";
    
    // $('#frame3 .glass').empty();
  //$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').empty();
    
     $("#frame3 .glass").css({
   'background-image' : 'url("images/largeglass/G4.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 .ovalglass").css({
   'background-image' : 'url("images/ovalglass/G4.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #oval-f1").css({
   'background-image' : 'url("images/ovalroundtop/G4.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $('#frame3 #tdglass1tri, #frame3 #tdglass2tri').css({
   'background-image' : 'url("images/doorglass/G4.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').css({
   'background-image' : 'url("images/largeglass/G4.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $("#frame3 #tdglassD5 .glass").css({
   'background-image': 'url("images/doorglass5/G4.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD8 .glass").css({
   'background-image': 'url("images/doorglass8/G4.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD9 div.glass").css({
   'background-image': 'url("images/doorglass9/G4.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #tdglassD3 div.glass").css({
   'background-image': 'url("images/ovalroundtop/G4.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #doorglassdefault2").css({
   'background-image': 'url("images/ovalroundtop/G4.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #table1 .glass").css({
   'background-image': 'url("images/smalldoorglass/G4.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
    $("#frame3 #table3 .glass, #frame3 #doorglassdefault1").css({
   'background-image': 'url("images/doorcenter/G4.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
});

$('#glass5').on('click', function () {
    isRedOrBlue = "glass5";
    
     //$('#frame3 .glass').empty();
//$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').empty();
    
     $("#frame3 .glass").css({
   'background-image' : 'url("images/largeglass/G5.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 .ovalglass").css({
   'background-image' : 'url("images/ovalglass/G5.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #oval-f1").css({
   'background-image' : 'url("images/ovalroundtop/G5.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $('#frame3 #tdglass1tri, #frame3 #tdglass2tri').css({
   'background-image' : 'url("images/doorglass/G5.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').css({
   'background-image' : 'url("images/largeglass/G5.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $("#frame3 #tdglassD5 .glass").css({
   'background-image': 'url("images/doorglass5/G5.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD8 .glass").css({
   'background-image': 'url("images/doorglass8/G5.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD9 div.glass").css({
   'background-image': 'url("images/doorglass9/G5.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #tdglassD3 div.glass").css({
   'background-image': 'url("images/ovalroundtop/G5.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #doorglassdefault2").css({
   'background-image': 'url("images/ovalroundtop/G5.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #table1 .glass").css({
   'background-image': 'url("images/smalldoorglass/G5.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
    $("#frame3 #table3 .glass, #frame3 #doorglassdefault1").css({
   'background-image': 'url("images/doorcenter/G5.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
});

$('#glass6').on('click', function () {
    isRedOrBlue = "glass6";
    
     //$('#frame3 .glass').empty();
//$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').empty();
    
     $("#frame3 .glass").css({
   'background-image' : 'url("images/largeglass/G6.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 .ovalglass").css({
   'background-image' : 'url("images/ovalglass/G6.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #oval-f1").css({
   'background-image' : 'url("images/ovalroundtop/G6.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $('#frame3 #tdglass1tri, #frame3 #tdglass2tri').css({
   'background-image' : 'url("images/doorglass/G6.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').css({
   'background-image' : 'url("images/largeglass/G6.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $("#frame3 #tdglassD5 .glass").css({
   'background-image': 'url("images/doorglass5/G6.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD8 .glass").css({
   'background-image': 'url("images/doorglass8/G6.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD9 div.glass").css({
   'background-image': 'url("images/doorglass9/G6.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #tdglassD3 div.glass").css({
   'background-image': 'url("images/ovalroundtop/G6.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #doorglassdefault2").css({
   'background-image': 'url("images/ovalroundtop/G6.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #table1 .glass").css({
   'background-image': 'url("images/smalldoorglass/G6.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
    $("#frame3 #table3 .glass, #frame3 #doorglassdefault1").css({
   'background-image': 'url("images/doorcenter/G6.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
});

$('#glass7').on('click', function () {
    isRedOrBlue = "glass7";
    
    // $('#frame3 .glass').empty();
//$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').empty();
    
     $("#frame3 .glass").css({
   'background-image' : 'url("images/largeglass/G7.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 .ovalglass").css({
   'background-image' : 'url("images/ovalglass/G7.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #oval-f1").css({
   'background-image' : 'url("images/ovalroundtop/G7.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $('#frame3 #tdglass1tri, #frame3 #tdglass2tri').css({
   'background-image' : 'url("images/doorglass/G7.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').css({
   'background-image' : 'url("images/largeglass/G7.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $("#frame3 #tdglassD5 .glass").css({
   'background-image': 'url("images/doorglass5/G7.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD8 .glass").css({
   'background-image': 'url("images/doorglass8/G7.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD9 div.glass").css({
   'background-image': 'url("images/doorglass9/G7.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #tdglassD3 div.glass").css({
   'background-image': 'url("images/ovalroundtop/G7.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #doorglassdefault2").css({
   'background-image': 'url("images/ovalroundtop/G7.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #table1 .glass").css({
   'background-image': 'url("images/smalldoorglass/G7.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
    $("#frame3 #table3 .glass, #frame3 #doorglassdefault1").css({
   'background-image': 'url("images/doorcenter/G7.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
});

$('#glass8').on('click', function () {
    isRedOrBlue = "glass1";
    
     //$('#frame3 .glass').empty();  
//$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').empty();
    
     $("#frame3 .glass").css({
   'background-image' : 'url("images/largeglass/G8.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 .ovalglass").css({
   'background-image' : 'url("images/ovalglass/G8.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #oval-f1").css({
   'background-image' : 'url("images/ovalroundtop/G8.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $('#frame3 #tdglass1tri, #frame3 #tdglass2tri').css({
   'background-image' : 'url("images/doorglass/G8.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').css({
   'background-image' : 'url("images/largeglass/G8.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $("#frame3 #tdglassD5 .glass").css({
   'background-image': 'url("images/doorglass5/G8.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD8 .glass").css({
   'background-image': 'url("images/doorglass8/G8.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD9 div.glass").css({
   'background-image': 'url("images/doorglass9/G8.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #tdglassD3 div.glass").css({
   'background-image': 'url("images/ovalroundtop/G8.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #doorglassdefault2").css({
   'background-image': 'url("images/ovalroundtop/G8.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #table1 .glass").css({
   'background-image': 'url("images/smalldoorglass/G8.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
    $("#frame3 #table3 .glass, #frame3 #doorglassdefault1").css({
   'background-image': 'url("images/doorcenter/G8.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
});


$('#glass9').on('click', function () {
    isRedOrBlue = "glass1";
    // For identification, I'm adding border
    
    
    // $('#frame3 .glass').empty();  
//$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').empty();
    
     $("#frame3 .glass").css({
   'background-image' : 'url("images/largeglass/G9.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 .ovalglass").css({
   'background-image' : 'url("images/ovalglass/G9.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #oval-f1").css({
   'background-image' : 'url("images/ovalroundtop/G9.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $('#frame3 #tdglass1tri, #frame3 #tdglass2tri').css({
   'background-image' : 'url("images/doorglass/G9.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').css({
   'background-image' : 'url("images/largeglass/G9.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $("#frame3 #tdglassD5 .glass").css({
   'background-image': 'url("images/doorglass5/G9.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD8 .glass").css({
   'background-image': 'url("images/doorglass8/G9.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD9 div.glass").css({
   'background-image': 'url("images/doorglass9/G9.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #tdglassD3 div.glass").css({
   'background-image': 'url("images/ovalroundtop/G9.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #doorglassdefault2").css({
   'background-image': 'url("images/ovalroundtop/G9.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #table1 .glass").css({
   'background-image': 'url("images/smalldoorglass/G9.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
    $("#frame3 #table3 .glass, #frame3 #doorglassdefault1").css({
   'background-image': 'url("images/doorcenter/G9.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
});


$('#glass10').on('click', function () {
    isRedOrBlue = "glass1";
    // For identification, I'm adding border
    
    
    // $('#frame3 .glass').empty();  
//$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').empty();
    
     $("#frame3 .glass").css({
   'background-image' : 'url("images/largeglass/G10.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 .ovalglass").css({
   'background-image' : 'url("images/ovalglass/G10.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #oval-f1").css({
   'background-image' : 'url("images/ovalroundtop/G10.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $('#frame3 #tdglass1tri, #frame3 #tdglass2tri').css({
   'background-image' : 'url("images/doorglass/G10.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').css({
   'background-image' : 'url("images/largeglass/G10.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $("#frame3 #tdglassD5 .glass").css({
   'background-image': 'url("images/doorglass5/G10.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD8 .glass").css({
   'background-image': 'url("images/doorglass8/G10.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD9 div.glass").css({
   'background-image': 'url("images/doorglass9/G10.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #tdglassD3 div.glass").css({
   'background-image': 'url("images/ovalroundtop/G10.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #doorglassdefault2").css({
   'background-image': 'url("images/ovalroundtop/G10.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #table1 .glass").css({
   'background-image': 'url("images/smalldoorglass/G10.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
    $("#frame3 #table3 .glass, #frame3 #doorglassdefault1").css({
   'background-image': 'url("images/doorcenter/G10.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
});



$('#glass111').on('click', function () {
    isRedOrBlue = "glass1";
    // For identification, I'm adding border
    
    
    // $('#frame3 .glass').empty();  
//$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').empty();
    
     $("#frame3 .glass").css({
   'background-image' : 'url("images/largeglass/G11.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 .ovalglass").css({
   'background-image' : 'url("images/ovalglass/G11.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #oval-f1").css({
   'background-image' : 'url("images/ovalroundtop/G11.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $('#frame3 #tdglass1tri, #frame3 #tdglass2tri').css({
   'background-image' : 'url("images/doorglass/G11.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').css({
   'background-image' : 'url("images/largeglass/G11.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $("#frame3 #tdglassD5 .glass").css({
   'background-image': 'url("images/doorglass5/G11.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD8 .glass").css({
   'background-image': 'url("images/doorglass8/G11.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD9 div.glass").css({
   'background-image': 'url("images/doorglass9/G11.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #tdglassD3 div.glass").css({
   'background-image': 'url("images/ovalroundtop/G11.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #doorglassdefault2").css({
   'background-image': 'url("images/ovalroundtop/G11.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #table1 .glass").css({
   'background-image': 'url("images/smalldoorglass/G11.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
    $("#frame3 #table3 .glass, #frame3 #doorglassdefault1").css({
   'background-image': 'url("images/doorcenter/G11.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
});


$('#glass12').on('click', function () {
    isRedOrBlue = "glass1";
    // For identification, I'm adding border
    
    
    // $('#frame3 .glass').empty();  
//$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').empty();
    
     $("#frame3 .glass").css({
   'background-image' : 'url("images/largeglass/G12.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 .ovalglass").css({
   'background-image' : 'url("images/ovalglass/G12.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #oval-f1").css({
   'background-image' : 'url("images/ovalroundtop/G12.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $('#frame3 #tdglass1tri, #frame3 #tdglass2tri').css({
   'background-image' : 'url("images/doorglass/G12.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').css({
   'background-image' : 'url("images/largeglass/G12.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $("#frame3 #tdglassD5 .glass").css({
   'background-image': 'url("images/doorglass5/G12.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD8 .glass").css({
   'background-image': 'url("images/doorglass8/G12.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD9 div.glass").css({
   'background-image': 'url("images/doorglass9/G12.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #tdglassD3 div.glass").css({
   'background-image': 'url("images/ovalroundtop/G12.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #doorglassdefault2").css({
   'background-image': 'url("images/ovalroundtop/G12.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #table1 .glass").css({
   'background-image': 'url("images/smalldoorglass/G12.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
    $("#frame3 #table3 .glass, #frame3 #doorglassdefault1").css({
   'background-image': 'url("images/doorcenter/G12.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
});


$('#glass13').on('click', function () {
    isRedOrBlue = "glass1";
    // For identification, I'm adding border
    
    
   //  $('#frame3 .glass').empty();  
//$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').empty();
    
     $("#frame3 .glass").css({
   'background-image' : 'url("images/largeglass/G13.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 .ovalglass").css({
   'background-image' : 'url("images/ovalglass/G13.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #oval-f1").css({
   'background-image' : 'url("images/ovalroundtop/G13.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $('#frame3 #tdglass1tri, #frame3 #tdglass2tri').css({
   'background-image' : 'url("images/doorglass/G13.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').css({
   'background-image' : 'url("images/largeglass/G13.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $("#frame3 #tdglassD5 .glass").css({
   'background-image': 'url("images/doorglass5/G13.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD8 .glass").css({
   'background-image': 'url("images/doorglass8/G13.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD9 div.glass").css({
   'background-image': 'url("images/doorglass9/G13.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #tdglassD3 div.glass").css({
   'background-image': 'url("images/ovalroundtop/G13.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #doorglassdefault2").css({
   'background-image': 'url("images/ovalroundtop/G13.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #table1 .glass").css({
   'background-image': 'url("images/smalldoorglass/G13.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
    $("#frame3 #table3 .glass, #frame3 #doorglassdefault1").css({
   'background-image': 'url("images/doorcenter/G13.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
});


$('#glass14').on('click', function () {
    isRedOrBlue = "glass1";
    // For identification, I'm adding border
    
    
   //  $('#frame3 .glass').empty();  
//$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').empty();
    
     $("#frame3 .glass").css({
   'background-image' : 'url("images/largeglass/G14.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 .ovalglass").css({
   'background-image' : 'url("images/ovalglass/G14.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #oval-f1").css({
   'background-image' : 'url("images/ovalroundtop/G14.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $('#frame3 #tdglass1tri, #frame3 #tdglass2tri').css({
   'background-image' : 'url("images/doorglass/G14.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').css({
   'background-image' : 'url("images/largeglass/G14.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $("#frame3 #tdglassD5 .glass").css({
   'background-image': 'url("images/doorglass5/G14.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD8 .glass").css({
   'background-image': 'url("images/doorglass8/G14.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD9 div.glass").css({
   'background-image': 'url("images/doorglass9/G14.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #tdglassD3 div.glass").css({
   'background-image': 'url("images/ovalroundtop/G14.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #doorglassdefault2").css({
   'background-image': 'url("images/ovalroundtop/G14.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #table1 .glass").css({
   'background-image': 'url("images/smalldoorglass/G14.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
    $("#frame3 #table3 .glass, #frame3 #doorglassdefault1").css({
   'background-image': 'url("images/doorcenter/G14.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
});


$('#glass15').on('click', function () {
    isRedOrBlue = "glass1";
    // For identification, I'm adding border
    
    
    // $('#frame3 .glass').empty();  
//$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').empty();
    
     $("#frame3 .glass").css({
   'background-image' : 'url("images/largeglass/G15.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 .ovalglass").css({
   'background-image' : 'url("images/ovalglass/G15.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #oval-f1").css({
   'background-image' : 'url("images/ovalroundtop/G15.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $('#frame3 #tdglass1tri, #frame3 #tdglass2tri').css({
   'background-image' : 'url("images/doorglass/G15.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').css({
   'background-image' : 'url("images/largeglass/G15.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $("#frame3 #tdglassD5 .glass").css({
   'background-image': 'url("images/doorglass5/G15.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD8 .glass").css({
   'background-image': 'url("images/doorglass8/G15.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD9 div.glass").css({
   'background-image': 'url("images/doorglass9/G15.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #tdglassD3 div.glass").css({
   'background-image': 'url("images/ovalroundtop/G15.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #doorglassdefault2").css({
   'background-image': 'url("images/ovalroundtop/G15.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #table1 .glass").css({
   'background-image': 'url("images/smalldoorglass/G15.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
    $("#frame3 #table3 .glass, #frame3 #doorglassdefault1").css({
   'background-image': 'url("images/doorcenter/G15.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
});


$('#glass16').on('click', function () {
    isRedOrBlue = "glass1";
    // For identification, I'm adding border
    
    
    // $('#frame3 .glass').empty();  
//$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').empty();
    
     $("#frame3 .glass").css({
   'background-image' : 'url("images/largeglass/G16.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 .ovalglass").css({
   'background-image' : 'url("images/ovalglass/G16.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #oval-f1").css({
   'background-image' : 'url("images/ovalroundtop/G16.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $('#frame3 #tdglass1tri, #frame3 #tdglass2tri').css({
   'background-image' : 'url("images/doorglass/G16.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').css({
   'background-image' : 'url("images/largeglass/G16.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $("#frame3 #tdglassD5 .glass").css({
   'background-image': 'url("images/doorglass5/G16.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD8 .glass").css({
   'background-image': 'url("images/doorglass8/G16.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD9 div.glass").css({
   'background-image': 'url("images/doorglass9/G16.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #tdglassD3 div.glass").css({
   'background-image': 'url("images/ovalroundtop/G16.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #doorglassdefault2").css({
   'background-image': 'url("images/ovalroundtop/G16.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #table1 .glass").css({
   'background-image': 'url("images/smalldoorglass/G16.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
    $("#frame3 #table3 .glass, #frame3 #doorglassdefault1").css({
   'background-image': 'url("images/doorcenter/G16.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
});


$('#glass17').on('click', function () {
    isRedOrBlue = "glass1";
    // For identification, I'm adding border
    
    
   //  $('#frame3 .glass').empty();  
//$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').empty();
    
     $("#frame3 .glass").css({
   'background-image' : 'url("images/largeglass/G17.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 .ovalglass").css({
   'background-image' : 'url("images/ovalglass/G17.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #oval-f1").css({
   'background-image' : 'url("images/ovalroundtop/G17.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $('#frame3 #tdglass1tri, #frame3 #tdglass2tri').css({
   'background-image' : 'url("images/doorglass/G17.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').css({
   'background-image' : 'url("images/largeglass/G17.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $("#frame3 #tdglassD5 .glass").css({
   'background-image': 'url("images/doorglass5/G17.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD8 .glass").css({
   'background-image': 'url("images/doorglass8/G17.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD9 div.glass").css({
   'background-image': 'url("images/doorglass9/G17.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #tdglassD3 div.glass").css({
   'background-image': 'url("images/ovalroundtop/G17.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #doorglassdefault2").css({
   'background-image': 'url("images/ovalroundtop/G17.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #table1 .glass").css({
   'background-image': 'url("images/smalldoorglass/G17.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
    $("#frame3 #table3 .glass, #frame3 #doorglassdefault1").css({
   'background-image': 'url("images/doorcenter/G17.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
});


$('#glass18').on('click', function () {
    isRedOrBlue = "glass1";
    // For identification, I'm adding border
    
    
    // $('#frame3 .glass').empty();  
//$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').empty();
    
     $("#frame3 .glass").css({
   'background-image' : 'url("images/largeglass/G18.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 .ovalglass").css({
   'background-image' : 'url("images/ovalglass/G18.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #oval-f1").css({
   'background-image' : 'url("images/ovalroundtop/G18.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $('#frame3 #tdglass1tri, #frame3 #tdglass2tri').css({
   'background-image' : 'url("images/doorglass/G18.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').css({
   'background-image' : 'url("images/largeglass/G18.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $("#frame3 #tdglassD5 .glass").css({
   'background-image': 'url("images/doorglass5/G18.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD8 .glass").css({
   'background-image': 'url("images/doorglass8/G18.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD9 div.glass").css({
   'background-image': 'url("images/doorglass9/G18.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #tdglassD3 div.glass").css({
   'background-image': 'url("images/ovalroundtop/G18.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #doorglassdefault2").css({
   'background-image': 'url("images/ovalroundtop/G18.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #table1 .glass").css({
   'background-image': 'url("images/smalldoorglass/G18.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
    $("#frame3 #table3 .glass, #frame3 #doorglassdefault1").css({
   'background-image': 'url("images/doorcenter/G18.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
});


$('#glass19').on('click', function () {
    isRedOrBlue = "glass1";
    // For identification, I'm adding border
    
    
   //  $('#frame3 .glass').empty();  
//$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').empty();
    
     $("#frame3 .glass").css({
   'background-image' : 'url("images/largeglass/G19.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 .ovalglass").css({
   'background-image' : 'url("images/ovalglass/G19.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #oval-f1").css({
   'background-image' : 'url("images/ovalroundtop/G19.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $('#frame3 #tdglass1tri, #frame3 #tdglass2tri').css({
   'background-image' : 'url("images/doorglass/G19.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').css({
   'background-image' : 'url("images/largeglass/G19.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
     $("#frame3 #tdglassD5 .glass").css({
   'background-image': 'url("images/doorglass5/G19.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD8 .glass").css({
   'background-image': 'url("images/doorglass8/G19.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD9 div.glass").css({
   'background-image': 'url("images/doorglass9/G19.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #tdglassD3 div.glass").css({
   'background-image': 'url("images/ovalroundtop/G19.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #doorglassdefault2").css({
   'background-image': 'url("images/ovalroundtop/G19.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #table1 .glass").css({
   'background-image': 'url("images/smalldoorglass/G19.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
    $("#frame3 #table3 .glass, #frame3 #doorglassdefault1").css({
   'background-image': 'url("images/doorcenter/G19.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
});


$('#glass20').on('click', function () {
    isRedOrBlue = "glass1";
    // For identification, I'm adding border
    
    
   //  $('#frame3 .glass').empty();  
//$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').empty();
    
     $("#frame3 .glass").css({
   'background-image' : 'url("images/largeglass/G20.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 .ovalglass").css({
   'background-image' : 'url("images/ovalglass/G20.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #oval-f1").css({
   'background-image' : 'url("images/ovalroundtop/G20.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $('#frame3 #tdglass1tri, #frame3 #tdglass2tri').css({
   'background-image' : 'url("images/doorglass/G20.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').css({
   'background-image' : 'url("images/largeglass/G20.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
     $("#frame3 #tdglassD5 .glass").css({
   'background-image': 'url("images/doorglass5/G20.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD8 .glass").css({
   'background-image': 'url("images/doorglass8/G20.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD9 div.glass").css({
   'background-image': 'url("images/doorglass9/G20.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #tdglassD3 div.glass").css({
   'background-image': 'url("images/ovalroundtop/G20.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #doorglassdefault2").css({
   'background-image': 'url("images/ovalroundtop/G20.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #table1 .glass").css({
   'background-image': 'url("images/smalldoorglass/G20.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
    $("#frame3 #table3 .glass, #frame3 #doorglassdefault1").css({
   'background-image': 'url("images/doorcenter/G20.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
});


$('#glass21').on('click', function () {
    isRedOrBlue = "glass1";
    // For identification, I'm adding border
    
    
   //  $('#frame3 .glass').empty();  
//$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').empty();
    
     $("#frame3 .glass").css({
   'background-image' : 'url("images/largeglass/G21.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 .ovalglass").css({
   'background-image' : 'url("images/ovalglass/G21.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #oval-f1").css({
   'background-image' : 'url("images/ovalroundtop/G21.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $('#frame3 #tdglass1tri, #frame3 #tdglass2tri').css({
   'background-image' : 'url("images/doorglass/G21.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').css({
   'background-image' : 'url("images/largeglass/G21.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
     $("#frame3 #tdglassD5 .glass").css({
   'background-image': 'url("images/doorglass5/G21.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD8 .glass").css({
   'background-image': 'url("images/doorglass8/G21.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD9 div.glass").css({
   'background-image': 'url("images/doorglass9/G21.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #tdglassD3 div.glass").css({
   'background-image': 'url("images/ovalroundtop/G21.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #doorglassdefault2").css({
   'background-image': 'url("images/ovalroundtop/G21.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #table1 .glass").css({
   'background-image': 'url("images/smalldoorglass/G21.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
    $("#frame3 #table3 .glass, #frame3 #doorglassdefault1").css({
   'background-image': 'url("images/doorcenter/G21.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
});


$('#glass22').on('click', function () {
    isRedOrBlue = "glass1";
    // For identification, I'm adding border
    
    
  //   $('#frame3 .glass').empty();  
//$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').empty();
    
     $("#frame3 .glass").css({
   'background-image' : 'url("images/largeglass/G22.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 .ovalglass").css({
   'background-image' : 'url("images/ovalglass/G22.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #oval-f1").css({
   'background-image' : 'url("images/ovalroundtop/G22.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $('#frame3 #tdglass1tri, #frame3 #tdglass2tri').css({
   'background-image' : 'url("images/doorglass/G22.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').css({
   'background-image' : 'url("images/largeglass/G22.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
     $("#frame3 #tdglassD5 .glass").css({
   'background-image': 'url("images/doorglass5/G22.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD8 .glass").css({
   'background-image': 'url("images/doorglass8/G22.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD9 div.glass").css({
   'background-image': 'url("images/doorglass9/G22.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #tdglassD3 div.glass").css({
   'background-image': 'url("images/ovalroundtop/G22.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #doorglassdefault2").css({
   'background-image': 'url("images/ovalroundtop/G22.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #table1 .glass").css({
   'background-image': 'url("images/smalldoorglass/G22.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
    $("#frame3 #table3 .glass, #frame3 #doorglassdefault1").css({
   'background-image': 'url("images/doorcenter/G22.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
});


$('#glass23').on('click', function () {
    isRedOrBlue = "glass1";
    // For identification, I'm adding border
    
    
   //  $('#frame3 .glass').empty();  
//$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').empty();
    
     $("#frame3 .glass").css({
   'background-image' : 'url("images/largeglass/G23.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 .ovalglass").css({
   'background-image' : 'url("images/ovalglass/G23.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #oval-f1").css({
   'background-image' : 'url("images/ovalroundtop/G23.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $('#frame3 #tdglass1tri, #frame3 #tdglass2tri').css({
   'background-image' : 'url("images/doorglass/G23.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').css({
   'background-image' : 'url("images/largeglass/G23.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
     $("#frame3 #tdglassD5 .glass").css({
   'background-image': 'url("images/doorglass5/G23.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD8 .glass").css({
   'background-image': 'url("images/doorglass8/G23.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD9 div.glass").css({
   'background-image': 'url("images/doorglass9/G23.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #tdglassD3 div.glass").css({
   'background-image': 'url("images/ovalroundtop/G23.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #doorglassdefault2").css({
   'background-image': 'url("images/ovalroundtop/G23.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #table1 .glass").css({
   'background-image': 'url("images/smalldoorglass/G23.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
    $("#frame3 #table3 .glass, #frame3 #doorglassdefault1").css({
   'background-image': 'url("images/doorcenter/G23.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
});


$('#glass24').on('click', function () {
    isRedOrBlue = "glass1";
    // For identification, I'm adding border
    
    
    // $('#frame3 .glass').empty();  
//$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').empty();
    
     $("#frame3 .glass").css({
   'background-image' : 'url("images/largeglass/G24.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 .ovalglass").css({
   'background-image' : 'url("images/ovalglass/G24.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #oval-f1").css({
   'background-image' : 'url("images/ovalroundtop/G24.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $('#frame3 #tdglass1tri, #frame3 #tdglass2tri').css({
   'background-image' : 'url("images/doorglass/G24.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').css({
   'background-image' : 'url("images/largeglass/G24.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
     $("#frame3 #tdglassD5 .glass").css({
   'background-image': 'url("images/doorglass5/G24.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD8 .glass").css({
   'background-image': 'url("images/doorglass8/G24.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD9 div.glass").css({
   'background-image': 'url("images/doorglass9/G24.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #tdglassD3 div.glass").css({
   'background-image': 'url("images/ovalroundtop/G24.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #doorglassdefault2").css({
   'background-image': 'url("images/ovalroundtop/G24.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #table1 .glass").css({
   'background-image': 'url("images/smalldoorglass/G24.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
    $("#frame3 #table3 .glass, #frame3 #doorglassdefault1").css({
   'background-image': 'url("images/doorcenter/G24.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
});


$('#glass25').on('click', function () {
    isRedOrBlue = "glass1";
    // For identification, I'm adding border
    
    
  //   $('#frame3 .glass').empty();  
//$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').empty();
    
     $("#frame3 .glass").css({
   'background-image' : 'url("images/largeglass/G25.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 .ovalglass").css({
   'background-image' : 'url("images/ovalglass/G25.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #oval-f1").css({
   'background-image' : 'url("images/ovalroundtop/G25.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $('#frame3 #tdglass1tri, #frame3 #tdglass2tri').css({
   'background-image' : 'url("images/doorglass/G25.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').css({
   'background-image' : 'url("images/largeglass/G25.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
     $("#frame3 #tdglassD5 .glass").css({
   'background-image': 'url("images/doorglass5/G25.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD8 .glass").css({
   'background-image': 'url("images/doorglass8/G25.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD9 div.glass").css({
   'background-image': 'url("images/doorglass9/G25.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #tdglassD3 div.glass").css({
   'background-image': 'url("images/ovalroundtop/G25.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #doorglassdefault2").css({
   'background-image': 'url("images/ovalroundtop/G25.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #table1 .glass").css({
   'background-image': 'url("images/smalldoorglass/G25.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
    $("#frame3 #table3 .glass, #frame3 #doorglassdefault1").css({
   'background-image': 'url("images/doorcenter/G25.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
});


$('#glass26').on('click', function () {
    isRedOrBlue = "glass1";
    // For identification, I'm adding border
    
    
   //  $('#frame3 .glass').empty();  
//$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').empty();
    
     $("#frame3 .glass").css({
   'background-image' : 'url("images/largeglass/G26.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 .ovalglass").css({
   'background-image' : 'url("images/ovalglass/G26.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #oval-f1").css({
   'background-image' : 'url("images/ovalroundtop/G26.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $('#frame3 #tdglass1tri, #frame3 #tdglass2tri').css({
   'background-image' : 'url("images/doorglass/G26.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').css({
   'background-image' : 'url("images/largeglass/G26.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
     $("#frame3 #tdglassD5 .glass").css({
   'background-image': 'url("images/doorglass5/G26.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD8 .glass").css({
   'background-image': 'url("images/doorglass8/G26.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD9 div.glass").css({
   'background-image': 'url("images/doorglass9/G26.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #tdglassD3 div.glass").css({
   'background-image': 'url("images/ovalroundtop/G26.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #doorglassdefault2").css({
   'background-image': 'url("images/ovalroundtop/G26.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #table1 .glass").css({
   'background-image': 'url("images/smalldoorglass/G26.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
    $("#frame3 #table3 .glass, #frame3 #doorglassdefault1").css({
   'background-image': 'url("images/doorcenter/G26.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
});


$('#glass27').on('click', function () {
    isRedOrBlue = "glass1";
    // For identification, I'm adding border
    
    
  //   $('#frame3 .glass').empty();  
//$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').empty();
    
     $("#frame3 .glass").css({
   'background-image' : 'url("images/largeglass/G27.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 .ovalglass").css({
   'background-image' : 'url("images/ovalglass/G27.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #oval-f1").css({
   'background-image' : 'url("images/ovalroundtop/G27.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $('#frame3 #tdglass1tri, #frame3 #tdglass2tri').css({
   'background-image' : 'url("images/doorglass/G27.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').css({
   'background-image' : 'url("images/largeglass/G27.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
     $("#frame3 #tdglassD5 .glass").css({
   'background-image': 'url("images/doorglass5/G27.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD8 .glass").css({
   'background-image': 'url("images/doorglass8/G27.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD9 div.glass").css({
   'background-image': 'url("images/doorglass9/G27.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #tdglassD3 div.glass").css({
   'background-image': 'url("images/ovalroundtop/G27.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #doorglassdefault2").css({
   'background-image': 'url("images/ovalroundtop/G27.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #table1 .glass").css({
   'background-image': 'url("images/smalldoorglass/G27.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
    $("#frame3 #table3 .glass, #frame3 #doorglassdefault1").css({
   'background-image': 'url("images/doorcenter/G27.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
});


$('#glass28').on('click', function () {
    isRedOrBlue = "glass1";
    // For identification, I'm adding border
    
    
   //  $('#frame3 .glass').empty();  
//$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').empty();
    
     $("#frame3 .glass").css({
   'background-image' : 'url("images/largeglass/G28.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 .ovalglass").css({
   'background-image' : 'url("images/ovalglass/G28.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #oval-f1").css({
   'background-image' : 'url("images/ovalroundtop/G28.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $('#frame3 #tdglass1tri, #frame3 #tdglass2tri').css({
   'background-image' : 'url("images/doorglass/G28.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').css({
   'background-image' : 'url("images/largeglass/G28.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
     $("#frame3 #tdglassD5 .glass").css({
   'background-image': 'url("images/doorglass5/G28.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD8 .glass").css({
   'background-image': 'url("images/doorglass8/G28.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD9 div.glass").css({
   'background-image': 'url("images/doorglass9/G28.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #tdglassD3 div.glass").css({
   'background-image': 'url("images/ovalroundtop/G28.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #doorglassdefault2").css({
   'background-image': 'url("images/ovalroundtop/G28.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #table1 .glass").css({
   'background-image': 'url("images/smalldoorglass/G28.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
    $("#frame3 #table3 .glass, #frame3 #doorglassdefault1").css({
   'background-image': 'url("images/doorcenter/G28.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
});


$('#glass29').on('click', function () {
    isRedOrBlue = "glass1";
    // For identification, I'm adding border
    
    
   //  $('#frame3 .glass').empty();  
//$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').empty();
    
     $("#frame3 .glass").css({
   'background-image' : 'url("images/largeglass/G29.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 .ovalglass").css({
   'background-image' : 'url("images/ovalglass/G29.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #oval-f1").css({
   'background-image' : 'url("images/ovalroundtop/G29.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $('#frame3 #tdglass1tri, #frame3 #tdglass2tri').css({
   'background-image' : 'url("images/doorglass/G29.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').css({
   'background-image' : 'url("images/largeglass/G29.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $("#frame3 #tdglassD5 .glass").css({
   'background-image': 'url("images/doorglass5/G29.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD8 .glass").css({
   'background-image': 'url("images/doorglass8/G29.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD9 div.glass").css({
   'background-image': 'url("images/doorglass9/G29.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #tdglassD3 div.glass").css({
   'background-image': 'url("images/ovalroundtop/G29.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #doorglassdefault2").css({
   'background-image': 'url("images/ovalroundtop/G29.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #table1 .glass").css({
   'background-image': 'url("images/smalldoorglass/G29.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
    $("#frame3 #table3 .glass, #frame3 #doorglassdefault1").css({
   'background-image': 'url("images/doorcenter/G29.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
});


$('#glass30').on('click', function () {
    isRedOrBlue = "glass1";
    // For identification, I'm adding border
    
    
  //   $('#frame3 .glass').empty();  
//$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').empty();
    
     $("#frame3 .glass").css({
   'background-image' : 'url("images/largeglass/G30.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 .ovalglass").css({
   'background-image' : 'url("images/ovalglass/G30.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #oval-f1").css({
   'background-image' : 'url("images/ovalroundtop/G30.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $('#frame3 #tdglass1tri, #frame3 #tdglass2tri').css({
   'background-image' : 'url("images/doorglass/G30.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').css({
   'background-image' : 'url("images/largeglass/G30.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $("#frame3 #tdglassD5 .glass").css({
   'background-image': 'url("images/doorglass5/G30.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD8 .glass").css({
   'background-image': 'url("images/doorglass8/G30.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD9 div.glass").css({
   'background-image': 'url("images/doorglass9/G30.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #tdglassD3 div.glass").css({
   'background-image': 'url("images/ovalroundtop/G30.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #doorglassdefault2").css({
   'background-image': 'url("images/ovalroundtop/G30.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #table1 .glass").css({
   'background-image': 'url("images/smalldoorglass/G30.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
    $("#frame3 #table3 .glass, #frame3 #doorglassdefault1").css({
   'background-image': 'url("images/doorcenter/G30.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
});


$('#glass31').on('click', function () {
    isRedOrBlue = "glass1";
    // For identification, I'm adding border
    
    
   //  $('#frame3 .glass').empty();  
//$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').empty();
    
     $("#frame3 .glass").css({
   'background-image' : 'url("images/largeglass/G31.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 .ovalglass").css({
   'background-image' : 'url("images/ovalglass/G31.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #oval-f1").css({
   'background-image' : 'url("images/ovalroundtop/G31.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $('#frame3 #tdglass1tri, #frame3 #tdglass2tri').css({
   'background-image' : 'url("images/doorglass/G31.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').css({
   'background-image' : 'url("images/largeglass/G31.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $("#frame3 #tdglassD5 .glass").css({
   'background-image': 'url("images/doorglass5/G31.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD8 .glass").css({
   'background-image': 'url("images/doorglass8/G31.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD9 div.glass").css({
   'background-image': 'url("images/doorglass9/G31.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #tdglassD3 div.glass").css({
   'background-image': 'url("images/ovalroundtop/G31.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #doorglassdefault2").css({
   'background-image': 'url("images/ovalroundtop/G31.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #table1 .glass").css({
   'background-image': 'url("images/smalldoorglass/G31.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
    $("#frame3 #table3 .glass, #frame3 #doorglassdefault1").css({
   'background-image': 'url("images/doorcenter/G31.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
});


$('#glass32').on('click', function () {
    isRedOrBlue = "glass1";
    // For identification, I'm adding border
    
    
  //   $('#frame3 .glass').empty();  
//$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').empty();
    
     $("#frame3 .glass").css({
   'background-image' : 'url("images/largeglass/G32.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 .ovalglass").css({
   'background-image' : 'url("images/ovalglass/G32.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #oval-f1").css({
   'background-image' : 'url("images/ovalroundtop/G32.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $('#frame3 #tdglass1tri, #frame3 #tdglass2tri').css({
   'background-image' : 'url("images/doorglass/G32.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').css({
   'background-image' : 'url("images/largeglass/G32.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $("#frame3 #tdglassD5 .glass").css({
   'background-image': 'url("images/doorglass5/G32.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD8 .glass").css({
   'background-image': 'url("images/doorglass8/G32.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD9 div.glass").css({
   'background-image': 'url("images/doorglass9/G32.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #tdglassD3 div.glass").css({
   'background-image': 'url("images/ovalroundtop/G32.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #doorglassdefault2").css({
   'background-image': 'url("images/ovalroundtop/G32.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #table1 .glass").css({
   'background-image': 'url("images/smalldoorglass/G32.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
    $("#frame3 #table3 .glass, #frame3 #doorglassdefault1").css({
   'background-image': 'url("images/doorcenter/G32.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
});


$('#glass33').on('click', function () {
    isRedOrBlue = "glass1";
    // For identification, I'm adding border
    
    
  //   $('#frame3 .glass').empty();  
//$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').empty();
    
     $("#frame3 .glass").css({
   'background-image' : 'url("images/largeglass/G33.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 .ovalglass").css({
   'background-image' : 'url("images/ovalglass/G33.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #oval-f1").css({
   'background-image' : 'url("images/ovalroundtop/G33.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $('#frame3 #tdglass1tri, #frame3 #tdglass2tri').css({
   'background-image' : 'url("images/doorglass/G33.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').css({
   'background-image' : 'url("images/largeglass/G33.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $("#frame3 #tdglassD5 .glass").css({
   'background-image': 'url("images/doorglass5/G33.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD8 .glass").css({
   'background-image': 'url("images/doorglass8/G33.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD9 div.glass").css({
   'background-image': 'url("images/doorglass9/G33.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #tdglassD3 div.glass").css({
   'background-image': 'url("images/ovalroundtop/G33.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #doorglassdefault2").css({
   'background-image': 'url("images/ovalroundtop/G33.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #table1 .glass").css({
   'background-image': 'url("images/smalldoorglass/G33.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
    $("#frame3 #table3 .glass, #frame3 #doorglassdefault1").css({
   'background-image': 'url("images/doorcenter/G33.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
});


$('#glass34').on('click', function () {
    isRedOrBlue = "glass1";
    // For identification, I'm adding border
    
    
  //   $('#frame3 .glass').empty();  
//$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').empty();
    
     $("#frame3 .glass").css({
   'background-image' : 'url("images/largeglass/G34.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 .ovalglass").css({
   'background-image' : 'url("images/ovalglass/G34.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #oval-f1").css({
   'background-image' : 'url("images/ovalroundtop/G34.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
    $('#frame3 #tdglass1tri, #frame3 #tdglass2tri').css({
   'background-image' : 'url("images/doorglass/G34.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').css({
   'background-image' : 'url("images/largeglass/G34.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $("#frame3 #tdglassD5 .glass").css({
   'background-image': 'url("images/doorglass5/G34.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD5 .glass").css({
   'background-image': 'url("images/doorglass5/G34.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD8 .glass").css({
   'background-image': 'url("images/doorglass8/G34.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD9 div.glass").css({
   'background-image': 'url("images/doorglass9/G34.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #tdglassD3 div.glass").css({
   'background-image': 'url("images/ovalroundtop/G34.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #doorglassdefault2").css({
   'background-image': 'url("images/ovalroundtop/G34.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #table1 .glass").css({
   'background-image': 'url("images/smalldoorglass/G34.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
    $("#frame3 #table3 .glass, #frame3 #doorglassdefault1").css({
   'background-image': 'url("images/doorcenter/G34.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
});


$('#glass35').on('click', function () {
    isRedOrBlue = "glass1";
    // For identification, I'm adding border
    
    
  //   $('#frame3 .glass').empty();  
//$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').empty();
    
     $("#frame3 .glass").css({
   'background-image' : 'url("images/largeglass/G35.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 .ovalglass").css({
   'background-image' : 'url("images/ovalglass/G35.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #oval-f1").css({
   'background-image' : 'url("images/ovalroundtop/G35.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $('#frame3 #tdglass1tri, #frame3 #tdglass2tri').css({
   'background-image' : 'url("images/doorglass/G35.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').css({
   'background-image' : 'url("images/largeglass/G35.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $("#frame3 #tdglassD5 .glass").css({
   'background-image': 'url("images/doorglass5/G35.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD8 .glass").css({
   'background-image': 'url("images/doorglass8/G35.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD9 div.glass").css({
   'background-image': 'url("images/doorglass9/G35.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #tdglassD3 div.glass").css({
   'background-image': 'url("images/ovalroundtop/G35.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #doorglassdefault2").css({
   'background-image': 'url("images/ovalroundtop/G35.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #table1 .glass").css({
   'background-image': 'url("images/smalldoorglass/G35.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
    $("#frame3 #table3 .glass, #frame3 #doorglassdefault1").css({
   'background-image': 'url("images/doorcenter/G35.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
});


$('#glass36').on('click', function () {
    isRedOrBlue = "glass1";
    // For identification, I'm adding border
    
    
   //  $('#frame3 .glass').empty();  
//$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').empty();
    
     $("#frame3 .glass").css({
   'background-image' : 'url("images/largeglass/G36.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    
    $("#frame3 .ovalglass").css({
   'background-image' : 'url("images/ovalglass/G36.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #oval-f1").css({
   'background-image' : 'url("images/ovalroundtop/G36.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $('#frame3 #tdglass1tri, #frame3 #tdglass2tri').css({
   'background-image' : 'url("images/doorglass/G36.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $('#frame3 #tdglass1, #frame3 #tdglass2, #frame3 .glassbottom').css({
   'background-image' : 'url("images/largeglass/G36.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $("#frame3 #tdglassD5 .glass").css({
   'background-image': 'url("images/doorglass5/G36.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD8 .glass").css({
   'background-image': 'url("images/doorglass8/G36.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #tdglassD9 div.glass").css({
   'background-image': 'url("images/doorglass9/G36.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #tdglassD3 div.glass").css({
   'background-image': 'url("images/ovalroundtop/G36.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #doorglassdefault2").css({
   'background-image': 'url("images/ovalroundtop/G36.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
        $("#frame3 #table1 .glass").css({
   'background-image': 'url("images/smalldoorglass/G36.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
    $("#frame3 #table3 .glass, #frame3 #doorglassdefault1").css({
   'background-image': 'url("images/doorcenter/G36.jpg")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
});