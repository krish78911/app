$('#doorcenter1').on('click', function () {
    isRedOrBlue = "#doorcenter1";
    
    var bag = $('#frame3 .glass').css('background-image');
    var handle = $('#frame3 .doorhandle').css('background-image');
     var letterbox = $('#frame3 .doorletterbox').css('background-image');
     var knocker = $('#frame3 .glass').css('background-image');
    
    var doorback = $('#frame3 #beforecenter div.doorimage').css('background-image');
     doorback = doorback.replace('.png','.jpg');
     doorback=doorback.split('/');     //images, services, image.jpg
     var lastelem = doorback.pop();
     var lastelem1 = doorback.pop();//images, services     // lastelem: image.jpg
     doorback.push('D1');     //images, services, large   // lastelem: image.jpg 
     doorback.push(lastelem);    //images, services, large, image.jpg
     doorback=doorback.join('/');  //"images/services/large/image.jpg"
     $(this).attr('src', doorback);
    
     $('div#displaydoor div div#beforecenter').empty();
$('#doorcenter1').clone().appendTo($('div#displaydoor div div#beforecenter'));
    
    $('div#displaydoor div div#beforecenter div#doorcenter1').css({'border-color': '#acacac', 'height': '340px', 'width': '138px', 'background-image': doorback});
   /* $('#frame3 #oval').css({
        'background-color': 'red',
        'color': 'white',
        'font-size': '44px'
    });*/
   /* $("#frame3 .glass").css({
   'background-image': bag,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              }); */
    $("#frame3 #table23 .doorhandle").css({
   'background-image': handle,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '94px',
   'margin-left': '90px',
   'height': '30px',
   'width': '30px'
                              });
    $("#frame3 #table2 .doorletterbox").css({
   'background-image': letterbox,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '29px',
   'margin-right': '25%',
   'margin-left': '75%',
   'height': '15px',
   'width': '50px'
                              });
});

$('#doorcenter2').on('click', function () {
     isRedOrBlue = "#doorcenter2";
     var bag = $('#frame3 .glass').css('background-image');
     var handle = $('#frame3 .doorhandle').css('background-image');
     var letterbox = $('#frame3 .doorletterbox').css('background-image');
     var knocker = $('#frame3 .glass').css('background-image');
    
     var doorback = $('#frame3 #beforecenter div.doorimage').css('background-image');
     doorback = doorback.replace('.png','.jpg');
     doorback=doorback.split('/');     //images, services, image.jpg
     var lastelem = doorback.pop();
     var lastelem1 = doorback.pop();//images, services     // lastelem: image.jpg
     doorback.push('D2');     //images, services, large   // lastelem: image.jpg 
     doorback.push(lastelem);    //images, services, large, image.jpg
     doorback=doorback.join('/');  //"images/services/large/image.jpg"
     $(this).attr('src', doorback);
    
     $('div#displaydoor div div#beforecenter').empty();
$('#doorcenter2').clone().appendTo($('div#displaydoor div div#beforecenter'));
    
    $('div#displaydoor div div#beforecenter div#doorcenter2').css({'border-color': '#acacac', 'height': '340px', 'width': '138px', 'background-image': doorback});
    /* $("#frame3 .glass").css({
   'background-image': bag,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              }); */
    $("#frame3 #table23 .doorhandle").css({
   'background-image': handle,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '120px',
   'margin-right': '-130px',
   'float': 'right',
   'height': '30px',
   'width': '30px'
                              });
    $("#frame3 #table2 .doorletterbox").css({
   'background-image': letterbox,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '35px auto',
   'margin-left': '75%',
   'margin-right': '25%',
   'height': '15px',
   'width': '50px'
                              });
});


$('#doorcenter3').on('click', function () {
    isRedOrBlue = "#doorcenter3";
     var bag = $('#frame3 .glass').css('background-image');
     var handle = $('#frame3 .doorhandle').css('background-image');
     var letterbox = $('#frame3 .doorletterbox').css('background-image');
     var knocker = $('#frame3 .glass').css('background-image');
    
     var msrc = $('#frame3 .glass').css('background-image');
     msrc = msrc.replace('.jpg','.png');
     msrc=msrc.split('/');     //images, services, image.jpg
     var lastelem = msrc.pop();
     var lastelem1 = msrc.pop();//images, services     // lastelem: image.jpg
     msrc.push('ovalroundtop');     //images, services, large   // lastelem: image.jpg 
     msrc.push(lastelem);    //images, services, large, image.jpg
     msrc=msrc.join('/');  //"images/services/large/image.jpg"
     $(this).attr('src', msrc);
    
    var exts = ['.jpg', '.gif', '.png'];
$('#frame3 .glass').each(function(){
    var $t = $(this);
    $.each(exts, function(i,v){
        $t.css('background-image').replace(v, '');
       
    });
});
    
    var doorback = $('#frame3 #beforecenter div.doorimage').css('background-image');
     doorback = doorback.replace('.png','.jpg');
     doorback=doorback.split('/');     //images, services, image.jpg
     var lastelem = doorback.pop();
     var lastelem1 = doorback.pop();//images, services     // lastelem: image.jpg
     doorback.push('D3');     //images, services, large   // lastelem: image.jpg 
     doorback.push(lastelem);    //images, services, large, image.jpg
     doorback=doorback.join('/');  //"images/services/large/image.jpg"
     $(this).attr('src', doorback);
    
     $('div#displaydoor div div#beforecenter').empty();
$('#doorcenter3').clone().appendTo($('div#displaydoor div div#beforecenter'));
    
     $('div#displaydoor div div#beforecenter div#doorcenter3').css({'border-color': '#acacac', 'height': '340px', 'width': '138px', 'background-image': doorback});
     $('div#displaydoor div div#beforecenter div#doorcenter3 table').css({'margin': '0px auto', 'width': '100%'});
     $('div#displaydoor div div#beforecenter div#doorcenter3 div.glass').css({'margin': '0px auto', 'width': '75%', 'height':'40px', 'border-radius': '50% / 100%', 'border-bottom-left-radius': '0', 'border-bottom-right-radius': '0'});
     /* $("#frame3 .glass").css({
   'background-image': bag,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              }); */
    $("#frame3 #tdglassD3 div.glass").css({
   'background-image': msrc,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #table23 .doorhandle").css({
   'background-image': handle,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '94px',
   'margin-right': '2px',
   'float': 'right',
   'height': '30px',
   'width': '30px'
                              });
    $("#frame3 #table2 .doorletterbox").css({
   'background-image': letterbox,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '0px auto',
   'height': '15px',
   'width': '50px'
                              });
});



$('#doorcenter4').on('click', function () {
    isRedOrBlue = "#doorcenter4";
     var bag = $('#frame3 .glass').css('background-image');
     var handle = $('#frame3 .doorhandle').css('background-image');
     var letterbox = $('#frame3 .doorletterbox').css('background-image');
     var knocker = $('#frame3 .glass').css('background-image');
    
     var doorback = $('#frame3 #beforecenter div.doorimage').css('background-image');
     doorback = doorback.replace('.png','.jpg');
     doorback=doorback.split('/');     //images, services, image.jpg
     var lastelem = doorback.pop();
     var lastelem1 = doorback.pop();//images, services     // lastelem: image.jpg
     doorback.push('D4');     //images, services, large   // lastelem: image.jpg 
     doorback.push(lastelem);    //images, services, large, image.jpg
     doorback=doorback.join('/');  //"images/services/large/image.jpg"
     $(this).attr('src', doorback);
    
     var msrc = $('#frame3 .glass').css('background-image');
     msrc = msrc.replace('.png','.jpg');
     msrc=msrc.split('/');     //images, services, image.jpg
     var lastelem = msrc.pop();
     var lastelem1 = msrc.pop();//images, services     // lastelem: image.jpg
     msrc.push('doorglass9');     //images, services, large   // lastelem: image.jpg 
     msrc.push(lastelem);    //images, services, large, image.jpg
     msrc=msrc.join('/');  //"images/services/large/image.jpg"
     $(this).attr('src', msrc);
     $('div#displaydoor div div#beforecenter').empty();
$('#doorcenter4').clone().appendTo($('div#displaydoor div div#beforecenter'));
    
    $('div#displaydoor div div#beforecenter div#doorcenter4').css({'border-color': '#acacac', 'height': '340px', 'width': '138px', 'background-image': doorback});
    
    $('div#displaydoor div div#beforecenter div#doorcenter4 table').css({'margin': '16px auto', 'width': '100%'});
    $('div#displaydoor div div#beforecenter div#doorcenter4 div.glass').css({'margin': '15px auto', 'width': '35%', 'height':'65px', 'border-radius': '5px'});
   /* $("#frame3 .glass").css({
   'background-image': bag,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              }); */
    $("#frame3 #tdglassD4 .glass").css({
   'background-image': msrc,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #table23 .doorhandle").css({
   'background-image': handle,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-46px',
   'margin-left': '5px',
   'height': '30px',
   'width': '30px',
   'float': 'right'
                              });
    $("#frame3 #table2 .doorletterbox").css({
   'background-image': letterbox,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-17px auto',
   'height': '15px',
   'width': '50px'
                              });
});


$('#doorcenter5').on('click', function () {
    isRedOrBlue = "#doorcenter5";   
    var bag = $('#frame3 .glass').css('background-image');
    var handlel = $('#frame3 .doorhandlel').css('background-image');
    var handler = $('#frame3 .doorhandler').css('background-image');
     var letterbox = $('#frame3 .doorletterbox').css('background-image');
     var knocker = $('#frame3 .glass').css('background-image');
    
     var doorback = $('#frame3 #beforecenter div.doorimage').css('background-image');
     doorback = doorback.replace('.png','.jpg');
     doorback=doorback.split('/');     //images, services, image.jpg
     var lastelem = doorback.pop();
     var lastelem1 = doorback.pop();//images, services     // lastelem: image.jpg
     doorback.push('D5');     //images, services, large   // lastelem: image.jpg 
     doorback.push(lastelem);    //images, services, large, image.jpg
     doorback=doorback.join('/');  //"images/services/large/image.jpg"
     $(this).attr('src', doorback);
    
     var msrc = $('#frame3 .glass').css('background-image');
     msrc = msrc.replace('.jpg','.png');
     msrc=msrc.split('/');     //images, services, image.jpg
     var lastelem = msrc.pop();
     var lastelem1 = msrc.pop();//images, services     // lastelem: image.jpg
     msrc.push('doorglass5');     //images, services, large   // lastelem: image.jpg 
     msrc.push(lastelem);    //images, services, large, image.jpg
     msrc=msrc.join('/');  //"images/services/large/image.jpg"
     $(this).attr('src', msrc);
    
     $('div#displaydoor div div#beforecenter').empty();
$('#doorcenter5').clone().appendTo($('div#displaydoor div div#beforecenter'));
    
    $('div#displaydoor div div#beforecenter div#doorcenter5').css({'border-color': '#acacac', 'height': '340px', 'width': '138px', 'background-image': doorback});
    
    $('div#displaydoor div div#beforecenter div#doorcenter5 table').css({'margin': '5px auto', 'width': '100%', 'background-color': 'rgba(167, 83, 83, 0)'});
    $('div#displaydoor div div#beforecenter div#doorcenter5 #handles').css({'margin': '0px auto', 'width': '100%', 'background-color': 'rgba(255, 0, 0, 0)'});
    $('div#displaydoor div div#beforecenter div#doorcenter5 #handles tr td').css({'width': '33%'});
    //$('div#displaydoor div div#beforecenter div#doorcenter5 div.tdglassD5').css({'margin': '0px auto', 'width': '70%', 'height':'140px', 'background-color': 'rgb(157, 65, 65)'});
    $('div#displaydoor div div#beforecenter div#doorcenter5 div.glass').css({'margin': '0px auto', 'width': '85px', 'height':'185px', 'background-color': 'rgba(255, 0, 0, 0)'});
   /* $("#frame3 .glass").css({
   'background-image': bag,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              }); */
    $("#frame3 #tdglassD5 .glass").css({
   'background-image': msrc,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #handles .doorhandlel").css({
   'background-image': handlel,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top':'-80px',
   'margin-left': '0px',
   'float': 'left',
   'height': '40px',
   'width': '30px'
                              });
    $("#frame3 #handles .doorhandler").css({
   'background-image': handler,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top':'-80px',
   'margin-right': '0px',
   'float': 'right',
   'height': '40px',
   'width': '30px'
                              });
    $("#frame3 #handles .doorletterbox").css({
   'background-image': letterbox,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-5px auto',
   'height': '15px',
   'width': '50px'
                              });
});



$('#doorcenter6').on('click', function () {
    isRedOrBlue = "#doorcenter6";
    var bag = $('#frame3 .glass').css('background-image');
    var handle = $('#frame3 .doorhandle').css('background-image');
     var letterbox = $('#frame3 .doorletterbox').css('background-image');
     var knocker = $('#frame3 .glass').css('background-image');
    
     var doorback = $('#frame3 #beforecenter div.doorimage').css('background-image');
     doorback = doorback.replace('.png','.jpg');
     doorback=doorback.split('/');     //images, services, image.jpg
     var lastelem = doorback.pop();
     var lastelem1 = doorback.pop();//images, services     // lastelem: image.jpg
     doorback.push('D6');     //images, services, large   // lastelem: image.jpg 
     doorback.push(lastelem);    //images, services, large, image.jpg
     doorback=doorback.join('/');  //"images/services/large/image.jpg"
     $(this).attr('src', doorback);
    
    var msrc = $('#frame3 .glass').css('background-image');
     msrc = msrc.replace('.jpg','.png');
     msrc=msrc.split('/');     //images, services, image.jpg
     var lastelem = msrc.pop();
     var lastelem1 = msrc.pop();//images, services     // lastelem: image.jpg
     msrc.push('doorglass');     //images, services, large   // lastelem: image.jpg 
     msrc.push(lastelem);    //images, services, large, image.jpg
     msrc=msrc.join('/');  //"images/services/large/image.jpg"
     $(this).attr('src', msrc);
    
     $('div#displaydoor div div#beforecenter').empty();
$('#doorcenter6').clone().appendTo($('div#displaydoor div div#beforecenter'));
    
    $('div#displaydoor div div#beforecenter div#doorcenter6').css({'border-color': '#acacac', 'height': '340px', 'width': '138px', 'background-image': doorback});
    
    //$('div#displaydoor div div#beforecenter div#doorcenter6 table').css({'width': '90%', 'height':'120px', 'border-spacing': '10px', 'margin': '-6px auto'});
  // $('div#displaydoor div div#beforecenter div#doorcenter6 table tr td#tdglass1').css({'margin-left': '5px', 'width': '50%', 'height':'110px', 'border-top': '10px solid transparent', 'border-right': '30px solid red', 'border-bottom': '10px solid transparent'});
   // $('div#displaydoor div div#beforecenter div#doorcenter6 table tr td#tdglass2').css({'margin-right': '5px', 'width': '50%', 'height':'110px', 'border-top': '10px solid rgba(255, 0, 0, 0)', 'border-left': '30px solid rgba(255, 0, 0, 0)', 'border-bottom': '10px solid rgba(255, 0, 0, 0)'});
    
    $('div#displaydoor div div#beforecenter div#doorcenter6 table').css({'width': '95%', 'height':'120px', 'border-spacing': '20px', 'margin': '-12px auto'}); 
    $('div#displaydoor div div#beforecenter div#doorcenter6 table tr td#tdglass1tri').css({'margin-left': '10px', 'width': '45%', 'height':'160px', 'background-color': 'rgba(255, 255, 255, 0)'});
    $('div#displaydoor div div#beforecenter div#doorcenter6 table tr td#tdglass2tri').css({'margin-right': '10px', 'width': '45%', 'height':'160px', 'background-color': 'rgba(255, 255, 255, 0)'});
   /* $("#frame3 .glass").css({
   'background-image': bag,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              }); */
    $('#frame3 #tdglass1tri, #frame3 #tdglass2tri').css({
   'background-image' : msrc,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $("#frame3 #table23 .doorhandle").css({
   'background-image': handle,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-70px',
   'margin-right': '-17px',
   'float': 'right',
   'height': '25px',
   'width': '30px'
                              });
    $("#frame3 #table2 .doorletterbox").css({
   'background-image': letterbox,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-160px auto',
   'height': '15px',
   'width': '50px'
                              });
});



$('#doorcenter7').on('click', function () {
     isRedOrBlue = "#doorcenter7";
     var bag = $('#frame3 .glass').css('background-image');
     var handle = $('#frame3 .doorhandle').css('background-image');
     var letterbox = $('#frame3 .doorletterbox').css('background-image');
     var knocker = $('#frame3 .glass').css('background-image');
    
     var doorback = $('#frame3 #beforecenter div.doorimage').css('background-image');
     doorback = doorback.replace('.png','.jpg');
     doorback=doorback.split('/');     //images, services, image.jpg
     var lastelem = doorback.pop();
     var lastelem1 = doorback.pop();//images, services     // lastelem: image.jpg
     doorback.push('D7');     //images, services, large   // lastelem: image.jpg 
     doorback.push(lastelem);    //images, services, large, image.jpg
     doorback=doorback.join('/');  //"images/services/large/image.jpg"
     $(this).attr('src', doorback);
    
     var msrc = $('#frame3 .glass').css('background-image');
     msrc = msrc.replace('.png','.jpg');
     msrc=msrc.split('/');     //images, services, image.jpg
     var lastelem = msrc.pop();
     var lastelem1 = msrc.pop();//images, services     // lastelem: image.jpg
     msrc.push('largeglass');     //images, services, large   // lastelem: image.jpg 
     msrc.push(lastelem);    //images, services, large, image.jpg
     msrc=msrc.join('/');  //"images/services/large/image.jpg"
     $(this).attr('src', msrc);
    
     $('div#displaydoor div div#beforecenter').empty();
$('#doorcenter7').clone().appendTo($('div#displaydoor div div#beforecenter'));
    
    $('div#displaydoor div div#beforecenter div#doorcenter7').css({'border-color': '#acacac', 'height': '340px', 'width': '138px', 'background-image': doorback});
    $('div#displaydoor div div#beforecenter div#doorcenter7 table').css({'width': '90%', 'height':'170px', 'border-spacing': '15px', 'margin': '0px auto'});
   $('div#displaydoor div div#beforecenter div#doorcenter7 table tr td#tdglass1').css({'border': '1px solid #b7b6b6', 'margin-left': '5px', 'width': '50%', 'height':'170px'});
    $('div#displaydoor div div#beforecenter div#doorcenter7 table tr td#tdglass2').css({'border': '1px solid #b7b6b6', 'margin-right': '10px', 'width': '50%', 'height':'170px'});
   //$('div#displaydoor div div#beforecenter div#doorcenter7 div.glass71').css({'border-color': '#acacac', 'height': '270px', 'width': '120px'});
  /* $("#frame3 .glass").css({
   'background-image': bag,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              }); */
    $('#frame3 #tdglass1, #frame3 #tdglass2').css({
   'background-image' : msrc,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $("#frame3 #table23 .doorhandle").css({
   'background-image': handle,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-105px',
   'margin-right': '-17px',
   'float': 'right',
   'height': '25px',
   'width': '30px'
                              });
    $("#frame3 #table2 .doorletterbox").css({
   'background-image': letterbox,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-260px auto',
   'height': '15px',
   'width': '50px'
                              });
    
});



$('#doorcenter8').on('click', function () {
    isRedOrBlue = "#doorcenter8";
    var bag = $('#frame3 .glass').css('background-image');
    var handle = $('#frame3 .doorhandle').css('background-image');
     var letterbox = $('#frame3 .doorletterbox').css('background-image');
     var knocker = $('#frame3 .glass').css('background-image');
    
     var doorback = $('#frame3 #beforecenter div.doorimage').css('background-image');
     doorback = doorback.replace('.png','.jpg');
     doorback=doorback.split('/');     //images, services, image.jpg
     var lastelem = doorback.pop();
     var lastelem1 = doorback.pop();//images, services     // lastelem: image.jpg
     doorback.push('D8');     //images, services, large   // lastelem: image.jpg 
     doorback.push(lastelem);    //images, services, large, image.jpg
     doorback=doorback.join('/');  //"images/services/large/image.jpg"
     $(this).attr('src', doorback);
    
     var msrc = $('#frame3 .glass').css('background-image');
     msrc = msrc.replace('.jpg','.png');
     msrc=msrc.split('/');     //images, services, image.jpg
     var lastelem = msrc.pop();
     var lastelem1 = msrc.pop();//images, services     // lastelem: image.jpg
     msrc.push('doorglass8');     //images, services, large   // lastelem: image.jpg 
     msrc.push(lastelem);    //images, services, large, image.jpg
     msrc=msrc.join('/');  //"images/services/large/image.jpg"
     $(this).attr('src', msrc);
     $('div#displaydoor div div#beforecenter').empty();
     $('#doorcenter8').clone().appendTo($('div#displaydoor div div#beforecenter'));
    
    $('div#displaydoor div div#beforecenter div#doorcenter8').css({'border-color': '#acacac', 'height': '340px', 'width': '138px', 'background-image': doorback});
    
    $('div#displaydoor div div#beforecenter div#doorcenter8 table').css({'margin': '40px auto', 'width': '100%'});
    $('div#displaydoor div div#beforecenter div#doorcenter8 table tr td div#doorglassd8').css({'margin': '0px auto', 'width': '55px', 'height':'120px', 'background-color':'rgba(255, 0, 0, 0)'});
   /* $("#frame3 .glass").css({
   'background-image': bag,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              }); */
    $("#frame3 #doorglassd8").css({
   'background-image': msrc,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #table23 .doorhandle").css({
   'background-image': handle,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-20px',
   'margin-right': '5px',
   'float': 'right',
   'height': '30px',
   'width': '30px'
                              });
    $("#frame3 #table2 .doorletterbox").css({
   'background-image': letterbox,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-40px auto',
   'height': '15px',
   'width': '50px'
                              });
});



$('#doorcenter9').on('click', function () {
    isRedOrBlue = "#doorcenter9";
    var bag = $('#frame3 .glass').css('background-image');
    var handle = $('#frame3 .doorhandle').css('background-image');
     var letterbox = $('#frame3 .doorletterbox').css('background-image');
     var knocker = $('#frame3 .glass').css('background-image');
    
     var doorback = $('#frame3 #beforecenter div.doorimage').css('background-image');
     doorback = doorback.replace('.png','.jpg');
     doorback=doorback.split('/');     //images, services, image.jpg
     var lastelem = doorback.pop();
     var lastelem1 = doorback.pop();//images, services     // lastelem: image.jpg
     doorback.push('D9');     //images, services, large   // lastelem: image.jpg 
     doorback.push(lastelem);    //images, services, large, image.jpg
     doorback=doorback.join('/');  //"images/services/large/image.jpg"
     $(this).attr('src', doorback);
    
     var msrc = $('#frame3 .glass').css('background-image');
     msrc = msrc.replace('.png','.jpg');
     msrc=msrc.split('/');     //images, services, image.jpg
     var lastelem = msrc.pop();
     var lastelem1 = msrc.pop();//images, services     // lastelem: image.jpg
     msrc.push('doorglass9');     //images, services, large   // lastelem: image.jpg 
     msrc.push(lastelem);    //images, services, large, image.jpg
     msrc=msrc.join('/');  //"images/services/large/image.jpg"
     $(this).attr('src', msrc);
    
     $('div#displaydoor div div#beforecenter').empty();
     $('#doorcenter9').clone().appendTo($('div#displaydoor div div#beforecenter'));
    
    $('div#displaydoor div div#beforecenter div#doorcenter9').css({'border-color': '#acacac', 'height': '340px', 'width': '138px', 'background-image': doorback});
    
    $('div#displaydoor div div#beforecenter div#doorcenter9 table').css({'margin': '-2px auto', 'width': '100%'});
    $('div#displaydoor div div#beforecenter div#doorcenter9 div.glass').css({'margin': '0px auto', 'width': '65%', 'height':'168px', 'border-radius': '5px',});
   /* $("#frame3 .glass").css({
   'background-image': bag,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              }); */
     $("#frame3 #tdglassD9 div.glass").css({
   'background-image': msrc,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #table23 .doorhandle").css({
   'background-image': handle,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-8px',
   'margin-right': '5px',
   'float': 'right',
   'height': '25px',
   'width': '30px'
                              });
    $("#frame3 #table2 .doorletterbox").css({
   'background-image': letterbox,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-20px auto',
   'height': '15px',
   'width': '50px'
                              });
});

$('#doorcenter0').on('click', function () {
    isRedOrBlue = "#doorcenter0";
    var bag = $('#frame3 .glass').css('background-image');
    // For identification, I'm adding border
    $(this).css({
        "border": "1px solid #ccc"
    })
    //Vice versa I'm removing for other
    $('#frame1').css({
        "border": ""
    })
    
     $('div#displaydoor div div#beforecenter').empty();
$('#doorcenter0').clone().appendTo($('div#displaydoor div div#beforecenter'));
    
    $('div#displaydoor div div#beforecenter div#doorcenter0').css({'border-color': '#acacac', 'height': '270px', 'width': '120px'});
});



$('#doorcenter10').on('click', function () {
    isRedOrBlue = "#doorcenter10";
     var bag = $('#frame3 .glass').css('background-image');
     var handle = $('#frame3 .doorhandle').css('background-image');
     var letterbox = $('#frame3 .doorletterbox').css('background-image');
     var knocker = $('#frame3 .glass').css('background-image');
    
     var doorback = $('#frame3 #beforecenter div.doorimage').css('background-image');
     doorback = doorback.replace('.png','.jpg');
     doorback=doorback.split('/');     //images, services, image.jpg
     var lastelem = doorback.pop();
     var lastelem1 = doorback.pop();//images, services     // lastelem: image.jpg
     doorback.push('D10');     //images, services, large   // lastelem: image.jpg 
     doorback.push(lastelem);    //images, services, large, image.jpg
     doorback=doorback.join('/');  //"images/services/large/image.jpg"
     $(this).attr('src', doorback);
    
     var msrc = $('#frame3 .glass').css('background-image');
     msrc = msrc.replace('.png','.jpg');
     msrc=msrc.split('/');     //images, services, image.jpg
     var lastelem = msrc.pop();
     var lastelem1 = msrc.pop();//images, services     // lastelem: image.jpg
     msrc.push('doorglass9');     //images, services, large   // lastelem: image.jpg 
     msrc.push(lastelem);    //images, services, large, image.jpg
     msrc=msrc.join('/');  //"images/services/large/image.jpg"
     $(this).attr('src', msrc);
     $('div#displaydoor div div#beforecenter').empty();
$('#doorcenter10').clone().appendTo($('div#displaydoor div div#beforecenter'));
    
    $('div#displaydoor div div#beforecenter div#doorcenter10').css({'border-color': '#acacac', 'height': '340px', 'width': '138px', 'background-image': doorback});
    
    $('div#displaydoor div div#beforecenter div#doorcenter10 table').css({'margin': '16px auto', 'width': '100%'});
    $('div#displaydoor div div#beforecenter div#doorcenter10 div.glass').css({'margin': '15px auto', 'width': '35%', 'height':'65px', 'border-radius': '5px', 'visibility': 'hidden'});
   /* $("#frame3 .glass").css({
   'background-image': bag,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              }); */
    $("#frame3 #tdglassD4 .glass").css({
   'background-image': msrc,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
     $("#frame3 #table23 .doorhandle").css({
   'background-image': handle,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-46px',
   'margin-left': '5px',
   'height': '30px',
   'width': '30px',
   'float': 'right'
                              });
    $("#frame3 #table2 .doorletterbox").css({
   'background-image': letterbox,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-17px auto',
   'height': '15px',
   'width': '50px'
                              });
});




$('#doorcenter11').on('click', function () {
    isRedOrBlue = "#doorcenter11";   
    var bag = $('#frame3 .glass').css('background-image');
    var handle = $('#frame3 .doorhandle').css('background-image');
     var letterbox = $('#frame3 .doorletterbox').css('background-image');
     var knocker = $('#frame3 .glass').css('background-image');
    
     var doorback = $('#frame3 #beforecenter div.doorimage').css('background-image');
     doorback = doorback.replace('.png','.jpg');
     doorback=doorback.split('/');     //images, services, image.jpg
     var lastelem = doorback.pop();
     var lastelem1 = doorback.pop();//images, services     // lastelem: image.jpg
     doorback.push('D11');     //images, services, large   // lastelem: image.jpg 
     doorback.push(lastelem);    //images, services, large, image.jpg
     doorback=doorback.join('/');  //"images/services/large/image.jpg"
     $(this).attr('src', doorback);
    
     var msrc = $('#frame3 .glass').css('background-image');
     msrc = msrc.replace('.jpg','.png');
     msrc=msrc.split('/');     //images, services, image.jpg
     var lastelem = msrc.pop();
     var lastelem1 = msrc.pop();//images, services     // lastelem: image.jpg
     msrc.push('doorglass5');     //images, services, large   // lastelem: image.jpg 
     msrc.push(lastelem);    //images, services, large, image.jpg
     msrc=msrc.join('/');  //"images/services/large/image.jpg"
     $(this).attr('src', msrc);
    
     $('div#displaydoor div div#beforecenter').empty();
$('#doorcenter11').clone().appendTo($('div#displaydoor div div#beforecenter'));
    
    $('div#displaydoor div div#beforecenter div#doorcenter11').css({'border-color': '#acacac', 'height': '340px', 'width': '138px', 'background-image': doorback});
    
    $('div#displaydoor div div#beforecenter div#doorcenter11 table').css({'margin': '5px auto', 'width': '100%', 'background-color': 'rgba(167, 83, 83, 0)'});
    //$('div#displaydoor div div#beforecenter div#doorcenter5 div.tdglassD5').css({'margin': '0px auto', 'width': '70%', 'height':'140px', 'background-color': 'rgb(157, 65, 65)'});
    $('div#displaydoor div div#beforecenter div#doorcenter11 div.glass').css({'margin': '0px auto', 'width': '85px', 'height':'185px', 'background-color': 'rgba(255, 0, 0, 0)', 'visibility': 'hidden'});
   /* $("#frame3 .glass").css({
   'background-image': bag,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              }); */
    $("#frame3 #tdglassD5 .glass").css({
   'background-image': msrc,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #table23 .doorhandle").css({
   'background-image': handle,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-16px',
   'margin-right': '5px',
   'float': 'right',
   'height': '30px',
   'width': '30px'
                              });
    $("#frame3 #table2 .doorletterbox").css({
   'background-image': letterbox,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-20px auto',
   'height': '15px',
   'width': '50px'
                              });
});




$('#doorcenter12').on('click', function () {
    isRedOrBlue = "#doorcenter12";
    var bag = $('#frame3 .glass').css('background-image');
    var handle = $('#frame3 .doorhandle').css('background-image');
     var letterbox = $('#frame3 .doorletterbox').css('background-image');
     var knocker = $('#frame3 .glass').css('background-image');
    
     var doorback = $('#frame3 #beforecenter div.doorimage').css('background-image');
     doorback = doorback.replace('.png','.jpg');
     doorback=doorback.split('/');     //images, services, image.jpg
     var lastelem = doorback.pop();
     var lastelem1 = doorback.pop();//images, services     // lastelem: image.jpg
     doorback.push('D12');     //images, services, large   // lastelem: image.jpg 
     doorback.push(lastelem);    //images, services, large, image.jpg
     doorback=doorback.join('/');  //"images/services/large/image.jpg"
     $(this).attr('src', doorback);
    
    var msrc = $('#frame3 .glass').css('background-image');
     msrc = msrc.replace('.jpg','.png');
     msrc=msrc.split('/');     //images, services, image.jpg
     var lastelem = msrc.pop();
     var lastelem1 = msrc.pop();//images, services     // lastelem: image.jpg
     msrc.push('doorglass');     //images, services, large   // lastelem: image.jpg 
     msrc.push(lastelem);    //images, services, large, image.jpg
     msrc=msrc.join('/');  //"images/services/large/image.jpg"
     $(this).attr('src', msrc);
    
     $('div#displaydoor div div#beforecenter').empty();
$('#doorcenter12').clone().appendTo($('div#displaydoor div div#beforecenter'));
    
    $('div#displaydoor div div#beforecenter div#doorcenter12').css({'border-color': '#acacac', 'height': '340px', 'width': '138px', 'background-image': doorback});
    
    //$('div#displaydoor div div#beforecenter div#doorcenter6 table').css({'width': '90%', 'height':'120px', 'border-spacing': '10px', 'margin': '-6px auto'});
  // $('div#displaydoor div div#beforecenter div#doorcenter6 table tr td#tdglass1').css({'margin-left': '5px', 'width': '50%', 'height':'110px', 'border-top': '10px solid transparent', 'border-right': '30px solid red', 'border-bottom': '10px solid transparent'});
   // $('div#displaydoor div div#beforecenter div#doorcenter6 table tr td#tdglass2').css({'margin-right': '5px', 'width': '50%', 'height':'110px', 'border-top': '10px solid rgba(255, 0, 0, 0)', 'border-left': '30px solid rgba(255, 0, 0, 0)', 'border-bottom': '10px solid rgba(255, 0, 0, 0)'});
    
    $('div#displaydoor div div#beforecenter div#doorcenter12 table').css({'width': '95%', 'height':'120px', 'border-spacing': '20px', 'margin': '-12px auto'}); 
    $('div#displaydoor div div#beforecenter div#doorcenter12 table tr td#tdglass1tri').css({'margin-left': '10px', 'width': '45%', 'height':'160px', 'background-color': 'rgba(255, 255, 255, 0)', 'visibility': 'hidden'});
    $('div#displaydoor div div#beforecenter div#doorcenter12 table tr td#tdglass2tri').css({'margin-right': '10px', 'width': '45%', 'height':'160px', 'background-color': 'rgba(255, 255, 255, 0)', 'visibility': 'hidden'});
   /* $("#frame3 .glass").css({
   'background-image': bag,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              }); */
    $('#frame3 #tdglass1tri, #frame3 #tdglass2tri').css({
   'background-image' : msrc,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $("#frame3 #table23 .doorhandle").css({
   'background-image': handle,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-70px',
   'margin-right': '-17px',
   'float': 'right',
   'height': '25px',
   'width': '30px'
                              });
    $("#frame3 #table2 .doorletterbox").css({
   'background-image': letterbox,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-160px auto',
   'height': '15px',
   'width': '50px'
                              });
});




$('#doorcenter13').on('click', function () {
     isRedOrBlue = "#doorcenter13";
     var bag = $('#frame3 .glass').css('background-image');
     var handle = $('#frame3 .doorhandle').css('background-image');
     var letterbox = $('#frame3 .doorletterbox').css('background-image');
     var knocker = $('#frame3 .glass').css('background-image');
    
     var doorback = $('#frame3 #beforecenter div.doorimage').css('background-image');
     doorback = doorback.replace('.png','.jpg');
     doorback=doorback.split('/');     //images, services, image.jpg
     var lastelem = doorback.pop();
     var lastelem1 = doorback.pop();//images, services     // lastelem: image.jpg
     doorback.push('D13');     //images, services, large   // lastelem: image.jpg 
     doorback.push(lastelem);    //images, services, large, image.jpg
     doorback=doorback.join('/');  //"images/services/large/image.jpg"
     $(this).attr('src', doorback);
    
     var msrc = $('#frame3 .glass').css('background-image');
     msrc = msrc.replace('.png','.jpg');
     msrc=msrc.split('/');     //images, services, image.jpg
     var lastelem = msrc.pop();
     var lastelem1 = msrc.pop();//images, services     // lastelem: image.jpg
     msrc.push('largeglass');     //images, services, large   // lastelem: image.jpg 
     msrc.push(lastelem);    //images, services, large, image.jpg
     msrc=msrc.join('/');  //"images/services/large/image.jpg"
     $(this).attr('src', msrc);
    
     $('div#displaydoor div div#beforecenter').empty();
$('#doorcenter13').clone().appendTo($('div#displaydoor div div#beforecenter'));
    
    $('div#displaydoor div div#beforecenter div#doorcenter13').css({'border-color': '#acacac', 'height': '340px', 'width': '138px', 'background-image': doorback});
    $('div#displaydoor div div#beforecenter div#doorcenter13 table').css({'width': '90%', 'height':'170px', 'border-spacing': '15px', 'margin': '0px auto'});
   $('div#displaydoor div div#beforecenter div#doorcenter13 table tr td#tdglass1').css({'border': '1px solid #b7b6b6', 'margin-left': '5px', 'width': '50%', 'height':'170px', 'visibility':'hidden'});
    $('div#displaydoor div div#beforecenter div#doorcenter13 table tr td#tdglass2').css({'border': '1px solid #b7b6b6', 'margin-right': '10px', 'width': '50%', 'height':'170px', 'visibility':'hidden'});
   //$('div#displaydoor div div#beforecenter div#doorcenter7 div.glass71').css({'border-color': '#acacac', 'height': '270px', 'width': '120px'});
  /* $("#frame3 .glass").css({
   'background-image': bag,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              }); */
    $('#frame3 #tdglass1, #frame3 #tdglass2').css({
   'background-image' : msrc,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
         });
    $("#frame3 #table23 .doorhandle").css({
   'background-image': handle,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-105px',
   'margin-right': '-17px',
   'float': 'right',
   'height': '25px',
   'width': '30px'
                              });
    $("#frame3 #table2 .doorletterbox").css({
   'background-image': letterbox,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-260px auto',
   'height': '15px',
   'width': '50px'
                              });
    
});




$('#doorcenter14').on('click', function () {
    isRedOrBlue = "#doorcenter9";
    var bag = $('#frame3 .glass').css('background-image');
    var handle = $('#frame3 .doorhandle').css('background-image');
     var letterbox = $('#frame3 .doorletterbox').css('background-image');
     var knocker = $('#frame3 .glass').css('background-image');
    
     var doorback = $('#frame3 #beforecenter div.doorimage').css('background-image');
     doorback = doorback.replace('.png','.jpg');
     doorback=doorback.split('/');     //images, services, image.jpg
     var lastelem = doorback.pop();
     var lastelem1 = doorback.pop();//images, services     // lastelem: image.jpg
     doorback.push('D14');     //images, services, large   // lastelem: image.jpg 
     doorback.push(lastelem);    //images, services, large, image.jpg
     doorback=doorback.join('/');  //"images/services/large/image.jpg"
     $(this).attr('src', doorback);
    
     var msrc = $('#frame3 .glass').css('background-image');
     msrc = msrc.replace('.png','.jpg');
     msrc=msrc.split('/');     //images, services, image.jpg
     var lastelem = msrc.pop();
     var lastelem1 = msrc.pop();//images, services     // lastelem: image.jpg
     msrc.push('doorglass9');     //images, services, large   // lastelem: image.jpg 
     msrc.push(lastelem);    //images, services, large, image.jpg
     msrc=msrc.join('/');  //"images/services/large/image.jpg"
     $(this).attr('src', msrc);
    
     $('div#displaydoor div div#beforecenter').empty();
     $('#doorcenter14').clone().appendTo($('div#displaydoor div div#beforecenter'));
    
    $('div#displaydoor div div#beforecenter div#doorcenter14').css({'border-color': '#acacac', 'height': '340px', 'width': '138px', 'background-image': doorback});
    
    $('div#displaydoor div div#beforecenter div#doorcenter14 table').css({'margin': '-2px auto', 'width': '100%'});
    $('div#displaydoor div div#beforecenter div#doorcenter14 div.glass').css({'margin': '0px auto', 'width': '65%', 'height':'168px', 'border-radius': '5px', 'visibility': 'hidden'});
   /* $("#frame3 .glass").css({
   'background-image': bag,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              }); */
     $("#frame3 #tdglassD9 div.glass").css({
   'background-image': msrc,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #table23 .doorhandle").css({
   'background-image': handle,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-8px',
   'margin-right': '5px',
   'float': 'right',
   'height': '25px',
   'width': '30px'
                              });
    $("#frame3 #table2 .doorletterbox").css({
   'background-image': letterbox,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-20px auto',
   'height': '15px',
   'width': '50px'
                              });
});



$('#doorcenter15').on('click', function () {
    isRedOrBlue = "#doorcenter15";
    var bag = $('#frame3 .glass').css('background-image');
    var handle = $('#frame3 .doorhandle').css('background-image');
     var letterbox = $('#frame3 .doorletterbox').css('background-image');
     var knocker = $('#frame3 .glass').css('background-image');
    
     var doorback = $('#frame3 #beforecenter div.doorimage').css('background-image');
     doorback = doorback.replace('.png','.jpg');
     doorback=doorback.split('/');     //images, services, image.jpg
     var lastelem = doorback.pop();
     var lastelem1 = doorback.pop();//images, services     // lastelem: image.jpg
     doorback.push('D15');     //images, services, large   // lastelem: image.jpg 
     doorback.push(lastelem);    //images, services, large, image.jpg
     doorback=doorback.join('/');  //"images/services/large/image.jpg"
     $(this).attr('src', doorback);
    
     var msrc = $('#frame3 .glass').css('background-image');
     msrc = msrc.replace('.jpg','.png');
     msrc=msrc.split('/');     //images, services, image.jpg
     var lastelem = msrc.pop();
     var lastelem1 = msrc.pop();//images, services     // lastelem: image.jpg
     msrc.push('doorglass8');     //images, services, large   // lastelem: image.jpg 
     msrc.push(lastelem);    //images, services, large, image.jpg
     msrc=msrc.join('/');  //"images/services/large/image.jpg"
     $(this).attr('src', msrc);
     $('div#displaydoor div div#beforecenter').empty();
     $('#doorcenter15').clone().appendTo($('div#displaydoor div div#beforecenter'));
    
    $('div#displaydoor div div#beforecenter div#doorcenter15').css({'border-color': '#acacac', 'height': '340px', 'width': '138px', 'background-image': doorback});
    
    $('div#displaydoor div div#beforecenter div#doorcenter15 table').css({'margin': '40px auto', 'width': '100%'});
    $('div#displaydoor div div#beforecenter div#doorcenter15 table tr td div#doorglassd8').css({'margin': '0px auto', 'width': '55px', 'height':'120px', 'background-color':'rgba(255, 0, 0, 0)', 'visibility': 'hidden'});
   /* $("#frame3 .glass").css({
   'background-image': bag,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              }); */
    $("#frame3 #doorglassd8").css({
   'background-image': msrc,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #table23 .doorhandle").css({
   'background-image': handle,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-20px',
   'margin-right': '5px',
   'float': 'right',
   'height': '30px',
   'width': '30px'
                              });
    $("#frame3 #table2 .doorletterbox").css({
   'background-image': letterbox,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-40px auto',
   'height': '15px',
   'width': '50px'
                              });
});




$('#doorcenter16').on('click', function () {
    isRedOrBlue = "#doorcenter16";
    var bag = $('#frame3 .glass').css('background-image');
    var handle = $('#frame3 .doorhandle').css('background-image');
     var letterbox = $('#frame3 .doorletterbox').css('background-image');
     var knocker = $('#frame3 .glass').css('background-image');
    
     var doorback = $('#frame3 #beforecenter div.doorimage').css('background-image');
     doorback = doorback.replace('.png','.jpg');
     doorback=doorback.split('/');     //images, services, image.jpg
     var lastelem = doorback.pop();
     var lastelem1 = doorback.pop();//images, services     // lastelem: image.jpg
     doorback.push('D16');     //images, services, large   // lastelem: image.jpg 
     doorback.push(lastelem);    //images, services, large, image.jpg
     doorback=doorback.join('/');  //"images/services/large/image.jpg"
     $(this).attr('src', doorback);
    
     var msrc = $('#frame3 .glass').css('background-image');
     msrc = msrc.replace('.png','.jpg');
     msrc=msrc.split('/');     //images, services, image.jpg
     var lastelem = msrc.pop();
     var lastelem1 = msrc.pop();//images, services     // lastelem: image.jpg
     msrc.push('doorglass9');     //images, services, large   // lastelem: image.jpg 
     msrc.push(lastelem);    //images, services, large, image.jpg
     msrc=msrc.join('/');  //"images/services/large/image.jpg"
     $(this).attr('src', msrc);
    
     var smalldoorglass = $('#frame3 .glass').css('background-image');
     smalldoorglass = smalldoorglass.replace('.png','.jpg');
     smalldoorglass=smalldoorglass.split('/');     //images, services, image.jpg
     var lastelem = smalldoorglass.pop();
     var lastelem1 = smalldoorglass.pop();//images, services     // lastelem: image.jpg
     smalldoorglass.push('smalldoorglass');     //images, services, large   // lastelem: image.jpg 
     smalldoorglass.push(lastelem);    //images, services, large, image.jpg
     smalldoorglass=smalldoorglass.join('/');  //"images/services/large/image.jpg"
     $(this).attr('src', smalldoorglass);
    
     $('div#displaydoor div div#beforecenter').empty();
     $('#doorcenter16').clone().appendTo($('div#displaydoor div div#beforecenter'));
    
    $('div#displaydoor div div#beforecenter div#doorcenter16').css({'border-color': '#acacac', 'height': '340px', 'width': '138px', 'background-image': doorback});
    
    $('div#displaydoor div div#beforecenter div#doorcenter16 #table1').css({'margin': '0px auto', 'width': '100%', 'border-spacing': '26px 18px'});
    $('div#displaydoor div div#beforecenter div#doorcenter16 #table1 tr td').css({'width': '18px', 'height': '35px'});
    $('div#displaydoor div div#beforecenter div#doorcenter16 div.glass').css({'margin': '0px auto', 'width': '65%', 'height':'168px', 'border-radius': '5px',});
   /* $("#frame3 .glass").css({
   'background-image': bag,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              }); */
    $("#frame3 #table23 .doorhandle").css({
   'background-image': handle,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-8px',
   'margin-right': '5px',
   'float': 'right',
   'height': '25px',
   'width': '30px'
                              });
    $("#frame3 #table2 .doorletterbox").css({
   'background-image': letterbox,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-20px auto',
   'height': '15px',
   'width': '50px'
                              });
    
    $("#frame3 #table1 .glass").css({
   'background-image': smalldoorglass,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
});




$('#doorcenter17').on('click', function () {
    isRedOrBlue = "#doorcenter17";
    var bag = $('#frame3 .glass').css('background-image');
    var handle = $('#frame3 .doorhandle').css('background-image');
     var letterbox = $('#frame3 .doorletterbox').css('background-image');
     var knocker = $('#frame3 .glass').css('background-image');
    
     var doorback = $('#frame3 #beforecenter div.doorimage').css('background-image');
     doorback = doorback.replace('.png','.jpg');
     doorback=doorback.split('/');     //images, services, image.jpg
     var lastelem = doorback.pop();
     var lastelem1 = doorback.pop();//images, services     // lastelem: image.jpg
     doorback.push('D17');     //images, services, large   // lastelem: image.jpg 
     doorback.push(lastelem);    //images, services, large, image.jpg
     doorback=doorback.join('/');  //"images/services/large/image.jpg"
     $(this).attr('src', doorback);
    
     var msrc = $('#frame3 .glass').css('background-image');
     msrc = msrc.replace('.png','.jpg');
     msrc=msrc.split('/');     //images, services, image.jpg
     var lastelem = msrc.pop();
     var lastelem1 = msrc.pop();//images, services     // lastelem: image.jpg
     msrc.push('doorglass9');     //images, services, large   // lastelem: image.jpg 
     msrc.push(lastelem);    //images, services, large, image.jpg
     msrc=msrc.join('/');  //"images/services/large/image.jpg"
     $(this).attr('src', msrc);
    
     var smalldoorglass = $('#frame3 .glass').css('background-image');
     smalldoorglass = smalldoorglass.replace('.png','.jpg');
     smalldoorglass=smalldoorglass.split('/');     //images, services, image.jpg
     var lastelem = smalldoorglass.pop();
     var lastelem1 = smalldoorglass.pop();//images, services     // lastelem: image.jpg
     smalldoorglass.push('smalldoorglass');     //images, services, large   // lastelem: image.jpg 
     smalldoorglass.push(lastelem);    //images, services, large, image.jpg
     smalldoorglass=smalldoorglass.join('/');  //"images/services/large/image.jpg"
     $(this).attr('src', smalldoorglass);
    
     var doorcenter = $('#frame3 .glass').css('background-image');
     doorcenter = doorcenter.replace('.png','.jpg');
     doorcenter=doorcenter.split('/');     //images, services, image.jpg
     var lastelem = doorcenter.pop();
     var lastelem1 = doorcenter.pop();//images, services     // lastelem: image.jpg
     doorcenter.push('doorcenter');     //images, services, large   // lastelem: image.jpg 
     doorcenter.push(lastelem);    //images, services, large, image.jpg
     doorcenter=doorcenter.join('/');  //"images/services/large/image.jpg"
     $(this).attr('src', doorcenter);
    
     $('div#displaydoor div div#beforecenter').empty();
     $('#doorcenter17').clone().appendTo($('div#displaydoor div div#beforecenter'));
    
    $('div#displaydoor div div#beforecenter div#doorcenter17').css({'border-color': '#acacac', 'height': '340px', 'width': '138px', 'background-image': doorback});
    
    $('div#displaydoor div div#beforecenter div#doorcenter17 #table1').css({'margin': '0px auto', 'width': '100%', 'border-spacing': '26px 18px'});
    $('div#displaydoor div div#beforecenter div#doorcenter17 #table1 tr td').css({'width': '18px', 'height': '35px'});
    $('div#displaydoor div div#beforecenter div#doorcenter17 #table3').css({'margin': '0px auto', 'width': '100%', 'border-spacing': '22px 10px'});
    $('div#displaydoor div div#beforecenter div#doorcenter17 #table3 tr td').css({'width': '8px', 'height': '100px'});
    $('div#displaydoor div div#beforecenter div#doorcenter17 div.glass').css({'margin': '0px auto', 'width': '65%', 'height':'168px', 'border-radius': '5px',});
   /* $("#frame3 .glass").css({
   'background-image': bag,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              }); */

    $("#frame3 #table23 .doorhandle").css({
   'background-image': handle,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-8px',
   'margin-right': '5px',
   'float': 'right',
   'height': '25px',
   'width': '30px'
                              });
    $("#frame3 #table2 .doorletterbox").css({
   'background-image': letterbox,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-20px auto',
   'height': '15px',
   'width': '50px'
                              });
    $("#frame3 #table1 .glass").css({
   'background-image': smalldoorglass,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
    $("#frame3 #table3 .glass").css({
   'background-image': doorcenter,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
                              });
});




$('#doorcenter18').on('click', function () {
    isRedOrBlue = "#doorcenter18";
     var bag = $('#frame3 .glass').css('background-image');
     var handle = $('#frame3 .doorhandle').css('background-image');
     var letterbox = $('#frame3 .doorletterbox').css('background-image');
     var knocker = $('#frame3 .glass').css('background-image');
    
     var msrc = $('#frame3 .glass').css('background-image');
     msrc = msrc.replace('.jpg','.png');
     msrc=msrc.split('/');     //images, services, image.jpg
     var lastelem = msrc.pop();
     var lastelem1 = msrc.pop();//images, services     // lastelem: image.jpg
     msrc.push('ovalroundtop');     //images, services, large   // lastelem: image.jpg 
     msrc.push(lastelem);    //images, services, large, image.jpg
     msrc=msrc.join('/');  //"images/services/large/image.jpg"
     $(this).attr('src', msrc);
    
    var exts = ['.jpg', '.gif', '.png'];
$('#frame3 .glass').each(function(){
    var $t = $(this);
    $.each(exts, function(i,v){
        $t.css('background-image').replace(v, '');
       
    });
});
    
    var doorback = $('#frame3 #beforecenter div.doorimage').css('background-image');
     doorback = doorback.replace('.png','.jpg');
     doorback=doorback.split('/');     //images, services, image.jpg
     var lastelem = doorback.pop();
     var lastelem1 = doorback.pop();//images, services     // lastelem: image.jpg
     doorback.push('D18');     //images, services, large   // lastelem: image.jpg 
     doorback.push(lastelem);    //images, services, large, image.jpg
     doorback=doorback.join('/');  //"images/services/large/image.jpg"
     $(this).attr('src', doorback);
    
     $('div#displaydoor div div#beforecenter').empty();
$('#doorcenter18').clone().appendTo($('div#displaydoor div div#beforecenter'));
    
     $('div#displaydoor div div#beforecenter div#doorcenter18').css({'border-color': '#acacac', 'height': '340px', 'width': '138px', 'background-image': doorback});
     $('div#displaydoor div div#beforecenter div#doorcenter18 table').css({'margin': '0px auto', 'width': '100%'});
     $('div#displaydoor div div#beforecenter div#doorcenter18 div.glass').css({'margin': '0px auto', 'width': '75%', 'height':'40px', 'border-radius': '50% / 100%', 'border-bottom-left-radius': '0', 'border-bottom-right-radius': '0', 'visibility': 'hidden'});
     /* $("#frame3 .glass").css({
   'background-image': bag,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              }); */
    $("#frame3 #tdglassD3 div.glass").css({
   'background-image': msrc,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #table23 .doorhandle").css({
   'background-image': handle,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '94px',
   'margin-right': '2px',
   'float': 'right',
   'height': '30px',
   'width': '30px'
                              });
    $("#frame3 #table2 .doorletterbox").css({
   'background-image': letterbox,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '0px auto',
   'height': '15px',
   'width': '50px'
                              });
});



$('#doorcenter19').on('click', function () {
    isRedOrBlue = "#doorcenter19";
     var bag = $('#frame3 .glass').css('background-image');
     var handle = $('#frame3 .doorhandle').css('background-image');
     var letterbox = $('#frame3 .doorletterbox').css('background-image');
     var knocker = $('#frame3 .glass').css('background-image');
    
     var msrc = $('#frame3 .glass').css('background-image');
     msrc = msrc.replace('.jpg','.png');
     msrc=msrc.split('/');     //images, services, image.jpg
     var lastelem = msrc.pop();
     var lastelem1 = msrc.pop();//images, services     // lastelem: image.jpg
     msrc.push('ovalroundtop');     //images, services, large   // lastelem: image.jpg 
     msrc.push(lastelem);    //images, services, large, image.jpg
     msrc=msrc.join('/');  //"images/services/large/image.jpg"
     $(this).attr('src', msrc);
    
    var exts = ['.jpg', '.gif', '.png'];
$('#frame3 .glass').each(function(){
    var $t = $(this);
    $.each(exts, function(i,v){
        $t.css('background-image').replace(v, '');
       
    });
});
    
    var doorback = $('#frame3 #beforecenter div.doorimage').css('background-image');
     doorback = doorback.replace('.png','.jpg');
     doorback=doorback.split('/');     //images, services, image.jpg
     var lastelem = doorback.pop();
     var lastelem1 = doorback.pop();//images, services     // lastelem: image.jpg
     doorback.push('D19');     //images, services, large   // lastelem: image.jpg 
     doorback.push(lastelem);    //images, services, large, image.jpg
     doorback=doorback.join('/');  //"images/services/large/image.jpg"
     $(this).attr('src', doorback);
     
     var doorcenter = $('#frame3 .glass').css('background-image');
     doorcenter = doorcenter.replace('.png','.jpg');
     doorcenter=doorcenter.split('/');     //images, services, image.jpg
     var lastelem = doorcenter.pop();
     var lastelem1 = doorcenter.pop();//images, services     // lastelem: image.jpg
     doorcenter.push('doorcenter');     //images, services, large   // lastelem: image.jpg 
     doorcenter.push(lastelem);    //images, services, large, image.jpg
     doorcenter=doorcenter.join('/');  //"images/services/large/image.jpg"
     $(this).attr('src', doorcenter);
    
     $('div#displaydoor div div#beforecenter').empty();
$('#doorcenter19').clone().appendTo($('div#displaydoor div div#beforecenter'));
    
     $('div#displaydoor div div#beforecenter div#doorcenter19').css({'border-color': '#acacac', 'height': '340px', 'width': '138px', 'background-image': doorback});
     $('div#displaydoor div div#beforecenter div#doorcenter19 #table1').css({'margin': '0px auto', 'width': '100%', 'border-spacing': '20px 4px'});
    $('div#displaydoor div div#beforecenter div#doorcenter19 #table1 tr td').css({'width': '18px', 'height': '40px'});
     $('div#displaydoor div div#beforecenter div#doorcenter19 #table3').css({'margin': '0px auto', 'width': '100%', 'border-spacing': '22px 22px'});
    $('div#displaydoor div div#beforecenter div#doorcenter19 #table3 tr td').css({'width': '10px', 'height': '100px'});
     $('div#displaydoor div div#beforecenter div#doorcenter19 div.glass').css({'margin': '0px auto', 'width': '75%', 'height':'40px', 'border-radius': '50% / 100%', 'border-bottom-left-radius': '0', 'border-bottom-right-radius': '0', 'visibility': 'hidden'});
     /* $("#frame3 .glass").css({
   'background-image': bag,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              }); */
    $("#frame3 #table23 .doorhandle").css({
   'background-image': handle,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '94px',
   'margin-right': '2px',
   'float': 'right',
   'height': '30px',
   'width': '30px'
                              });
    $("#frame3 #table2 .doorletterbox").css({
   'background-image': letterbox,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '0px auto',
   'height': '15px',
   'width': '50px'
                              });
    $("#frame3 #doorglassdefault2").css({
   'background-image': msrc,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
    $("#frame3 #doorglassdefault1").css({
   'background-image': doorcenter,
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat'
                              });
});
