$('#panel1').on('click', function () {
    isRedOrBlue = "panel1";
    // For identification, I'm adding border
    
    
     $('#frame3 #doorpanel1').empty();  
     $('#frame3 #doorpanel2').empty();  
     $('#frame3 #doorpanel3').empty();  
    
     $('#frame3 #doorpanel1D1').empty();  
     $('#frame3 #doorpanel3D1').empty();  
    
     $('#frame3 #doorpanel1D2').empty();  
     $('#frame3 #doorpanel3D2').empty();
    
     $('#frame3 #doorpanel1D3').empty();  
     $('#frame3 #doorpanel3D3').empty();
    
     $('#frame3 #doorpanel1D4').empty();  
     $('#frame3 #doorpanel3D4').empty();
    
     $('#frame3 #doorpanel1D5').empty();  
     $('#frame3 #doorpanel3D5').empty();
    
     $('#frame3 #doorpanel1D6').empty();  
     $('#frame3 #doorpanel3D6').empty();
    
     $('#frame3 #doorpanel1D7').empty();  
     $('#frame3 #doorpanel3D7').empty();
    
     $('#frame3 #doorpanel1D8').empty();  
     $('#frame3 #doorpanel3D8').empty();
    
     $('#frame3 #doorpanel1D9').empty();  
     $('#frame3 #doorpanel3D9').empty();
//$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    
     $("#frame3 #doorpanel1D4").css({
   'background-image' : 'url("images/panel/PLbrass.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '20px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel2D4").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '2px auto',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel3D4").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '10px',
   'margin-left': '5px',
   'height': '30px',
   'width': '30px',
   'float': 'right'
                              });
    
   $("#frame3 #doorpanel1D1").css({
   'background-image' : 'url("images/panel/PLbrass.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '30px',
   'margin-right': '25%',
   'margin-left': '75%',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel2D1").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '2px auto',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel3D1").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '60px',
   'margin-left': '90px',
   'height': '30px',
   'width': '30px'
                              });
    
    
    $("#frame3 #doorpanel1D2").css({
   'background-image' : 'url("images/panel/PLbrass.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-55px',
   'margin-left': '10px',
   'height': '15px',
   'width': '50px'
                              });
    
    $("#frame3 #doorpanel3D2").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '120px',
   'margin-right': '-30px',
   'float': 'right',
   'height': '40px',
   'width': '30px'
                              });
    $("#frame3 #doorpanel3D2l").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '120px',
   'margin-left': '0px',
   'float': 'left',
   'height': '40px',
   'width': '30px'
                              });
    $("#frame3 #doorpanel1D2k").css({
   'background-image' : 'url("images/panel/PLbrass.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-350px',
   'margin-left': '10px',
   'height': '15px',
   'width': '50px'
                              });
    $("#frame3 #doorpanel1D21k").css({
   'background-image' : 'url("images/panel/PLbrass.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-440px',
   'margin-left': '10px',
   'height': '15px',
   'width': '50px'
                              });
    
    
   $("#frame3 #doorpanel1D16").css({
   'background-image' : 'url("images/panel/PLbrass.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-25px',
   'margin-left': '10px',
   'height': '15px',
   'width': '50px'
                              });
    
    $("#frame3 #doorpanel3D16").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '50px',
   'margin-right': '-30px',
   'float': 'right',
   'height': '40px',
   'width': '30px'
                              });
    $("#frame3 #doorpanel3D16l").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '50px',
   'margin-left': '0px',
   'float': 'left',
   'height': '40px',
   'width': '30px'
                              });
    $("#frame3 #doorpanel1D16k").css({
   'background-image' : 'url("images/panel/PLbrass.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-250px',
   'margin-left': '10px',
   'height': '15px',
   'width': '50px'
                              });
    
    $("#frame3 #doorpanel1D17").css({
   'background-image' : 'url("images/panel/PLbrass.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-180px',
   'margin-left': '10px',
   'height': '15px',
   'width': '50px'
                              });
    
    $("#frame3 #doorpanel3D17").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-250px',
   'margin-right': '-30px',
   'float': 'right',
   'height': '40px',
   'width': '30px'
                              });
    $("#frame3 #doorpanel3D17l").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-250px',
   'margin-left': '0px',
   'float': 'left',
   'height': '40px',
   'width': '30px'
                              });
    $("#frame3 #doorpanel1D17k").css({
   'background-image' : 'url("images/panel/PLbrass.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-320px',
   'margin-left': '10px',
   'height': '15px',
   'width': '50px'
                              });
    
    $("#frame3 #doorpanel2D3").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '2px auto',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel1D3").css({
   'background-image' : 'url("images/panel/PLbrass.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-35px auto',
   'height': '15px',
   'width': '50px'
                              });
    
    $("#frame3 #doorpanel3D3").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '45px',
   'margin-right': '2px',
   'float': 'right',
   'height': '40px',
   'width': '30px'
                              });
    $("#frame3 #doorpanel3D3l").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '45px',
   'margin-right': '2px',
   'float': 'left',
   'height': '40px',
   'width': '30px'
                              });
    $("#frame3 #doorpanel1D3k").css({
   'background-image' : 'url("images/panel/PLbrass.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-250px auto',
   'height': '15px',
   'width': '50px'
                              });
    
    
    $("#frame3 #doorpanel1D5").css({
   'background-image' : 'url("images/panel/PLbrass.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-5px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D5l").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top':'-80px',
   'margin-left': '0px',
   'float': 'left',
   'height': '40px',
   'width': '30px'
                              });
    $("#frame3 #doorpanel3D5").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top':'-80px',
   'margin-right': '0px',
   'float': 'right',
   'height': '40px',
   'width': '30px'
                              });

    $("#frame3 #doorpanel1D6").css({
   'background-image' : 'url("images/panel/PLbrass.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-70px auto',
   'margin-left': '-10px',   
   'height': '15px',
   'width': '50px'
                              });
    
   $("#frame3 #doorpanel3D6").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-70px',
   'margin-left': '-10px',
   'float': 'right',
   'height': '40px',
   'width': '30px'
                              });
   $("#frame3 #doorpanel3D6l").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-70px',
   'margin-left': '-20px',
   'float': 'left',
   'height': '40px',
   'width': '30px'
                              });
    
     $("#frame3 #doorpanel1D7").css({
   'background-image' : 'url("images/panel/PLbrass.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-130px',
   'margin-left': '-10px',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D7").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-105px',
   'margin-left': '-10px',
   'float': 'right',
   'height': '40px',
   'width': '30px'
                              });
    $("#frame3 #doorpanel3D7l").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-105px',
   'margin-left': '-10px',
   'float': 'right',
   'height': '40px',
   'width': '30px'
                              });
    
        
    $("#frame3 #doorpanel1D8").css({
   'background-image' : 'url("images/panel/PLbrass.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-40px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D8").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-20px',
   'margin-right': '5px',
   'float': 'right',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel1D9").css({
   'background-image' : 'url("images/panel/PLbrass.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-20px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D9").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-8px',
   'margin-right': '5px',
   'float': 'right',
   'height': '25px',
   'width': '30px'
                              });
    
    $('div#displaydoor div div#beforecenter div#doorcenter4 table').css({'margin': '-4px auto', 'width': '100%'});
    $('div#displaydoor div div#beforecenter div#doorcenter4 div.glass').css({'margin': '0px auto', 'width': '35%', 'height':'60px', 'border-radius': '5px'});
});



$('#panel2').on('click', function () {
    isRedOrBlue = "panel2";
    
     $('#frame3 #doorpanel1').empty();  
     $('#frame3 #doorpanel2').empty();  
     $('#frame3 #doorpanel3').empty();  
     $('#frame3 #doorpanel1D1').empty();  
     $('#frame3 #doorpanel1D2').empty();  
     $('#frame3 #doorpanel1D3').empty();  
     $('#frame3 #doorpanel1D4').empty();  
     $('#frame3 #doorpanel1D5').empty();  
     $('#frame3 #doorpanel1D6').empty();  
     $('#frame3 #doorpanel1D7').empty();  
     $('#frame3 #doorpanel1D8').empty();  
     $('#frame3 #doorpanel1D9').empty();  
    
    $("#frame3 #doorpanel1D4").css({
   'background-image' : 'url("images/panel/PLchrome.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '20px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel2D4").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '2px auto',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel3D4").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '10px',
   'margin-left': '5px',
   'height': '30px',
   'width': '30px',
   'float': 'right'
                              });
    
    $("#frame3 #doorpanel1D1").css({
   'background-image' : 'url("images/panel/PLchrome.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '30px',
   'margin-right': '25%',
   'margin-left': '75%',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel2D1").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '2px auto',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel3D1").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '60px',
   'margin-left': '90px',
   'height': '30px',
   'width': '30px'
                              });
    
    
    $("#frame3 #doorpanel1D2").css({
   'background-image' : 'url("images/panel/PLchrome.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '35px auto',
   'margin-left': '75%',
   'margin-right': '25%',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D2").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '120px',
   'margin-right': '-130px',
   'float': 'right',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel1D3").css({
   'background-image' : 'url("images/panel/PLchrome.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '0px auto',
   'height': '15px',
   'width': '50px'
                              });
    
   $("#frame3 #doorpanel2D3").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '2px auto',
   'height': '30px',
   'width': '30px'
                              });
    
     $("#frame3 #doorpanel3D3").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '60px',
   'margin-right': '2px',
   'float': 'right',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel1D5").css({
   'background-image' : 'url("images/panel/PLchrome.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-5px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D5").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top':'-80px',
   'margin-right': '0px',
   'float': 'right',
   'height': '40px',
   'width': '30px'
                              }); 
    
     $("#frame3 #doorpanel3D5l").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top':'-80px',
   'margin-left': '0px',
   'float': 'left',
   'height': '40px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel1D6").css({
   'background-image' : 'url("images/panel/PLchrome.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-160px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D6").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-70px',
   'margin-right': '-17px',
   'float': 'right',
   'height': '25px',
   'width': '30px'
                              });
    
     $("#frame3 #doorpanel1D7").css({
   'background-image' : 'url("images/panel/PLchrome.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-260px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D7").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-105px',
   'margin-right': '-17px',
   'float': 'right',
   'height': '25px',
   'width': '30px'
                              });
    
        
    $("#frame3 #doorpanel1D8").css({
   'background-image' : 'url("images/panel/PLchrome.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-40px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D8").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-20px',
   'margin-right': '5px',
   'float': 'right',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel1D9").css({
   'background-image' : 'url("images/panel/PLchrome.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-20px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D9").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-8px',
   'margin-right': '5px',
   'float': 'right',
   'height': '25px',
   'width': '30px'
                              });
    
    $('div#displaydoor div div#beforecenter div#doorcenter4 table').css({'margin': '-4px auto', 'width': '100%'});
    $('div#displaydoor div div#beforecenter div#doorcenter4 div.glass').css({'margin': '0px auto', 'width': '35%', 'height':'60px', 'border-radius': '5px'});
});


$('#panel3').on('click', function () {
    isRedOrBlue = "panel3";
    
     $('#frame3 #doorpanel1').empty();  
     $('#frame3 #doorpanel2').empty();  
     $('#frame3 #doorpanel3').empty();  
     $('#frame3 #doorpanel1D1').empty();  
     $('#frame3 #doorpanel1D2').empty();  
     $('#frame3 #doorpanel1D3').empty();  
     $('#frame3 #doorpanel1D4').empty();  
     $('#frame3 #doorpanel1D5').empty();  
     $('#frame3 #doorpanel1D6').empty();  
     $('#frame3 #doorpanel1D7').empty();  
     $('#frame3 #doorpanel1D8').empty();  
     $('#frame3 #doorpanel1D9').empty();  
    
    $("#frame3 #doorpanel1D4").css({
   'background-image' : 'url("images/panel/PLwhite.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '20px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel2D4").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '2px auto',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel3D4").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '10px',
   'margin-left': '5px',
   'height': '30px',
   'width': '30px',
   'float': 'right'
                              });
    
    
    $("#frame3 #doorpanel1D1").css({
   'background-image' : 'url("images/panel/PLwhite.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '30px',
   'margin-right': '25%',
   'margin-left': '75%',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel2D1").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '2px auto',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel3D1").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '60px',
   'margin-left': '90px',
   'height': '30px',
   'width': '30px'
                              });
    
    
    $("#frame3 #doorpanel1D2").css({
   'background-image' : 'url("images/panel/PLwhite.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '35px auto',
   'margin-left': '75%',
   'margin-right': '25%',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D2").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '120px',
   'margin-right': '-130px',
   'float': 'right',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel1D3").css({
   'background-image' : 'url("images/panel/PLwhite.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '0px auto',
   'height': '15px',
   'width': '50px'
                              });
    
   $("#frame3 #doorpanel2D3").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '2px auto',
   'height': '30px',
   'width': '30px'
                              });
    
     $("#frame3 #doorpanel3D3").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '60px',
   'margin-right': '2px',
   'float': 'right',
   'height': '30px',
   'width': '30px'
                              });

        $("#frame3 #doorpanel1D5").css({
   'background-image' : 'url("images/panel/PLwhite.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-5px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D5").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top':'-80px',
   'margin-right': '0px',
   'float': 'right',
   'height': '40px',
   'width': '30px'
                              }); 
    
     $("#frame3 #doorpanel3D5l").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top':'-80px',
   'margin-left': '0px',
   'float': 'left',
   'height': '40px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel1D6").css({
   'background-image' : 'url("images/panel/PLwhite.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-160px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D6").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-70px',
   'margin-right': '-17px',
   'float': 'right',
   'height': '25px',
   'width': '30px'
                              });
    
     $("#frame3 #doorpanel1D7").css({
   'background-image' : 'url("images/panel/PLwhite.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-260px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D7").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-105px',
   'margin-right': '-17px',
   'float': 'right',
   'height': '25px',
   'width': '30px'
                              });
    
        
    $("#frame3 #doorpanel1D8").css({
   'background-image' : 'url("images/panel/PLwhite.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-40px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D8").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-20px',
   'margin-right': '5px',
   'float': 'right',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel1D9").css({
   'background-image' : 'url("images/panel/PLwhite.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-20px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D9").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-8px',
   'margin-right': '5px',
   'float': 'right',
   'height': '25px',
   'width': '30px'
                              });
    
    $('div#displaydoor div div#beforecenter div#doorcenter4 table').css({'margin': '-4px auto', 'width': '100%'});
    $('div#displaydoor div div#beforecenter div#doorcenter4 div.glass').css({'margin': '0px auto', 'width': '35%', 'height':'60px', 'border-radius': '5px'});
});



$('#panel4').on('click', function () {
    isRedOrBlue = "panel4";
    
     $('#frame3 #doorpanel1').empty();  
     $('#frame3 #doorpanel2').empty();  
     $('#frame3 #doorpanel3').empty();  
     $('#frame3 #doorpanel1D1').empty();  
     $('#frame3 #doorpanel1D2').empty();  
     $('#frame3 #doorpanel1D3').empty();  
     $('#frame3 #doorpanel1D4').empty();  
     $('#frame3 #doorpanel1D5').empty();  
     $('#frame3 #doorpanel1D6').empty();  
     $('#frame3 #doorpanel1D7').empty();  
     $('#frame3 #doorpanel1D8').empty();  
     $('#frame3 #doorpanel1D9').empty();  
    
    $("#frame3 #doorpanel1D4").css({
   'background-image' : 'url("images/panel/PLblack.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '20px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel2D4").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '2px auto',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel3D4").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '10px',
   'margin-left': '5px',
   'height': '30px',
   'width': '30px',
   'float': 'right'
                              });
    
    
    $("#frame3 #doorpanel1D1").css({
   'background-image' : 'url("images/panel/PLblack.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '30px',
   'margin-right': '25%',
   'margin-left': '75%',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel2D1").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '2px auto',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel3D1").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '60px',
   'margin-left': '90px',
   'height': '30px',
   'width': '30px'
                              });
    
    
    $("#frame3 #doorpanel1D2").css({
   'background-image' : 'url("images/panel/PLblack.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '35px auto',
   'margin-left': '75%',
   'margin-right': '25%',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D2").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '120px',
   'margin-right': '-130px',
   'float': 'right',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel1D3").css({
   'background-image' : 'url("images/panel/PLblack.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '0px auto',
   'height': '15px',
   'width': '50px'
                              });
    
   $("#frame3 #doorpanel2D3").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '2px auto',
   'height': '30px',
   'width': '30px'
                              });
    
     $("#frame3 #doorpanel3D3").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '60px',
   'margin-right': '2px',
   'float': 'right',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel1D5").css({
   'background-image' : 'url("images/panel/PLblack.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-5px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D5").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top':'-80px',
   'margin-right': '0px',
   'float': 'right',
   'height': '40px',
   'width': '30px'
                              }); 
    
     $("#frame3 #doorpanel3D5l").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top':'-80px',
   'margin-left': '0px',
   'float': 'left',
   'height': '40px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel1D6").css({
   'background-image' : 'url("images/panel/PLblack.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-160px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D6").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-70px',
   'margin-right': '-17px',
   'float': 'right',
   'height': '25px',
   'width': '30px'
                              });
    
     $("#frame3 #doorpanel1D7").css({
   'background-image' : 'url("images/panel/PLblack.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-260px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D7").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-105px',
   'margin-right': '-17px',
   'float': 'right',
   'height': '25px',
   'width': '30px'
                              });
    
        
    $("#frame3 #doorpanel1D8").css({
   'background-image' : 'url("images/panel/PLblack.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-40px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D8").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-20px',
   'margin-right': '5px',
   'float': 'right',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel1D9").css({
   'background-image' : 'url("images/panel/PLblack.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-20px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D9").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-8px',
   'margin-right': '5px',
   'float': 'right',
   'height': '25px',
   'width': '30px'
                              });
    
    $('div#displaydoor div div#beforecenter div#doorcenter4 table').css({'margin': '-4px auto', 'width': '100%'});
    $('div#displaydoor div div#beforecenter div#doorcenter4 div.glass').css({'margin': '0px auto', 'width': '35%', 'height':'60px', 'border-radius': '5px'});
});


$('#panel5').on('click', function () {
    isRedOrBlue = "panel5";
    
     $('#frame3 #doorpanel1').empty();  
     $('#frame3 #doorpanel2').empty();  
     $('#frame3 #doorpanel3').empty();  
     $('#frame3 #doorpanel1D1').empty();  
     $('#frame3 #doorpanel1D2').empty();  
     $('#frame3 #doorpanel1D3').empty();  
     $('#frame3 #doorpanel1D4').empty();  
     $('#frame3 #doorpanel1D5').empty();  
     $('#frame3 #doorpanel1D6').empty();  
     $('#frame3 #doorpanel1D7').empty();  
     $('#frame3 #doorpanel1D8').empty();  
     $('#frame3 #doorpanel1D9').empty();  
    
    $("#frame3 #doorpanel1D4").css({
   'background-image' : 'none',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '20px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel2D4").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '2px auto',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel3D4").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '10px',
   'margin-left': '5px',
   'height': '30px',
   'width': '30px',
   'float': 'right'
                              });
    
    $("#frame3 #doorpanel1D1").css({
   'background-image' : 'none',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '30px',
   'margin-right': '25%',
   'margin-left': '75%',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel2D1").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '2px auto',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel3D1").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '60px',
   'margin-left': '90px',
   'height': '30px',
   'width': '30px'
                              });
    
    
    $("#frame3 #doorpanel1D2").css({
   'background-image' : 'none',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '35px auto',
   'margin-left': '75%',
   'margin-right': '25%',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D2").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '120px',
   'margin-right': '-130px',
   'float': 'right',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel1D3").css({
   'background-image' : 'none',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '0px auto',
   'height': '15px',
   'width': '50px'
                              });
    
   $("#frame3 #doorpanel2D3").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '2px auto',
   'height': '30px',
   'width': '30px'
                              });
    
     $("#frame3 #doorpanel3D3").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '60px',
   'margin-right': '2px',
   'float': 'right',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel1D5").css({
   'background-image' : 'none',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-5px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D5").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top':'-80px',
   'margin-right': '0px',
   'float': 'right',
   'height': '40px',
   'width': '30px'
                              }); 
    
     $("#frame3 #doorpanel3D5l").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top':'-80px',
   'margin-left': '0px',
   'float': 'left',
   'height': '40px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel1D6").css({
   'background-image' : 'none',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-160px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D6").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-70px',
   'margin-right': '-17px',
   'float': 'right',
   'height': '25px',
   'width': '30px'
                              });
    
     $("#frame3 #doorpanel1D7").css({
   'background-image' : 'none',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-260px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D7").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-105px',
   'margin-right': '-17px',
   'float': 'right',
   'height': '25px',
   'width': '30px'
                              });
    
        
    $("#frame3 #doorpanel1D8").css({
   'background-image' : 'none',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-40px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D8").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-20px',
   'margin-right': '5px',
   'float': 'right',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel1D9").css({
   'background-image' : 'none',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-20px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D9").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-8px',
   'margin-right': '5px',
   'float': 'right',
   'height': '25px',
   'width': '30px'
                              });
    
    $('div#displaydoor div div#beforecenter div#doorcenter4 table').css({'margin': '-4px auto', 'width': '100%'});
    $('div#displaydoor div div#beforecenter div#doorcenter4 div.glass').css({'margin': '0px auto', 'width': '35%', 'height':'60px', 'border-radius': '5px'});
});


$('#Hpanel1').on('click', function () {
    isRedOrBlue = "Hpanel1";
    // For identification, I'm adding border
    
    
     $('#frame3 #doorpanel3').empty();  
     $('#frame3 #doorpanel3D1').empty();  
     $('#frame3 #doorpanel3D2').empty(); 
     $('#frame3 #doorpanel3D3').empty();
     $('#frame3 #doorpanel3D4').empty(); 
     $('#frame3 #doorpanel3D5').empty();
     $('#frame3 #doorpanel3D6').empty(); 
     $('#frame3 #doorpanel3D7').empty(); 
     $('#frame3 #doorpanel3D8').empty();  
     $('#frame3 #doorpanel3D9').empty();
//$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    
     $("#frame3 #doorpanel1D4").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '20px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel2D4").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '2px auto',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel3D4").css({
   'background-image' : 'url("images/panel/Hbrass.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '10px',
   'margin-left': '5px',
   'height': '30px',
   'width': '30px',
   'float': 'right'
                              });
    
    $("#frame3 #doorpanel1D1").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '30px',
   'margin-right': '25%',
   'margin-left': '75%',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel2D1").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '2px auto',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel3D1").css({
   'background-image' : 'url("images/panel/Hbrass.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '60px',
   'margin-left': '90px',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel1D2").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-55px',
   'margin-left': '10px',
   'height': '15px',
   'width': '50px'
                              });
    $("#frame3 #doorpanel3D2").css({
   'background-image' : 'url("images/panel/Hbrass.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '120px',
   'margin-right': '-30px',
   'float': 'right',
   'height': '40px',
   'width': '30px'
                              });
    $("#frame3 #doorpanel3D2l").css({
   'background-image' : 'url("images/panel/Hbrassl.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '120px',
   'margin-left': '0px',
   'float': 'left',
   'height': '40px',
   'width': '30px'
                              });
    
    
    $("#frame3 #doorpanel1D16").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-25px',
   'margin-left': '10px',
   'height': '15px',
   'width': '50px'
                              });
    
    $("#frame3 #doorpanel3D16").css({
   'background-image' : 'url("images/panel/Hbrass.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '50px',
   'margin-right': '-30px',
   'float': 'right',
   'height': '40px',
   'width': '30px'
                              });
    $("#frame3 #doorpanel3D16l").css({
   'background-image' : 'url("images/panel/Hbrassl.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '50px',
   'margin-left': '0px',
   'float': 'left',
   'height': '40px',
   'width': '30px'
                              });
    
        $("#frame3 #doorpanel1D17").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-180px',
   'margin-left': '10px',
   'height': '15px',
   'width': '50px'
                              });
    
    $("#frame3 #doorpanel3D17").css({
   'background-image' : 'url("images/panel/Hbrass.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-250px',
   'margin-right': '-30px',
   'float': 'right',
   'height': '40px',
   'width': '30px'
                              });
    $("#frame3 #doorpanel3D17l").css({
   'background-image' : 'url("images/panel/Hbrassl.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-250px',
   'margin-left': '0px',
   'float': 'left',
   'height': '40px',
   'width': '30px'
                              });
    
    
    $("#frame3 #doorpanel1D3").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-35px auto',
   'height': '15px',
   'width': '50px'
                              });
    
    $("#frame3 #doorpanel3D3").css({
   'background-image' : 'url("images/panel/Hbrass.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '45px',
   'margin-right': '2px',
   'float': 'right',
   'height': '40px',
   'width': '30px'
                              });
    $("#frame3 #doorpanel3D3l").css({
   'background-image' : 'url("images/panel/Hbrassl.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '45px',
   'margin-right': '2px',
   'float': 'left',
   'height': '40px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel1D5").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-5px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D5l").css({
   'background-image' : 'url("images/panel/Hbrassl.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top':'-80px',
   'margin-left': '0px',
   'float': 'left',
   'height': '40px',
   'width': '30px'
                              });
    $("#frame3 #doorpanel3D5").css({
   'background-image' : 'url("images/panel/Hbrass.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top':'-80px',
   'margin-right': '0px',
   'float': 'right',
   'height': '40px',
   'width': '30px'
                              });
    
    
    $("#frame3 #doorpanel1D6").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-70px auto',
   'margin-left': '-10px',   
   'height': '15px',
   'width': '50px'
                              });
    
   $("#frame3 #doorpanel3D6").css({
   'background-image' : 'url("images/panel/Hbrass.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-70px',
   'margin-left': '-10px',
   'float': 'right',
   'height': '40px',
   'width': '30px'
                              });
   $("#frame3 #doorpanel3D6l").css({
   'background-image' : 'url("images/panel/Hbrassl.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-70px',
   'margin-left': '-20px',
   'float': 'left',
   'height': '40px',
   'width': '30px'
                              });

    
    $("#frame3 #doorpanel1D7").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-130px',
   'margin-left': '-10px',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D7").css({
   'background-image' : 'url("images/panel/Hbrass.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-105px',
   'margin-left': '-10px',
   'float': 'right',
   'height': '40px',
   'width': '30px'
                              });
    $("#frame3 #doorpanel3D7l").css({
   'background-image' : 'url("images/panel/Hbrassl.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-105px',
   'margin-left': '-10px',
   'float': 'right',
   'height': '40px',
   'width': '30px'
                              });
    
        
    $("#frame3 #doorpanel1D8").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-40px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D8").css({
   'background-image' : 'url("images/panel/Hbrass.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-20px',
   'margin-right': '5px',
   'float': 'right',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel1D9").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-20px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D9").css({
   'background-image' : 'url("images/panel/Hbrass.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-8px',
   'margin-right': '5px',
   'float': 'right',
   'height': '25px',
   'width': '30px'
                              });
    
    $('div#displaydoor div div#beforecenter div#doorcenter4 table').css({'margin': '-4px auto', 'width': '100%'});
    $('div#displaydoor div div#beforecenter div#doorcenter4 div.glass').css({'margin': '0px auto', 'width': '35%', 'height':'60px', 'border-radius': '5px'});
});




$('#Hpanel2').on('click', function () {
    isRedOrBlue = "Hpanel2";
    // For identification, I'm adding border
    
    
     $('#frame3 #doorpanel3').empty();  
     $('#frame3 #doorpanel3D1').empty();  
     $('#frame3 #doorpanel3D2').empty(); 
     $('#frame3 #doorpanel3D3').empty();
     $('#frame3 #doorpanel3D4').empty(); 
     $('#frame3 #doorpanel3D5').empty();
     $('#frame3 #doorpanel3D6').empty(); 
     $('#frame3 #doorpanel3D7').empty(); 
     $('#frame3 #doorpanel3D8').empty();  
     $('#frame3 #doorpanel3D9').empty();
//$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    
    $("#frame3 #doorpanel1D4").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '20px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel2D4").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '2px auto',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel3D4").css({
   'background-image' : 'url("images/panel/Hchrome.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '10px',
   'margin-left': '5px',
   'height': '30px',
   'width': '30px',
   'float': 'right'
                              });
    
    $("#frame3 #doorpanel1D1").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '30px',
   'margin-right': '25%',
   'margin-left': '75%',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel2D1").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '2px auto',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel3D1").css({
   'background-image' : 'url("images/panel/Hchrome.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '60px',
   'margin-left': '90px',
   'height': '30px',
   'width': '30px'
                              });
    
    
             $("#frame3 #doorpanel1D2").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '35px auto',
   'margin-left': '75%',
   'margin-right': '25%',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D2").css({
   'background-image' : 'url("images/panel/Hchrome.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '120px',
   'margin-right': '-130px',
   'float': 'right',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel1D3").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '0px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D3").css({
   'background-image' : 'url("images/panel/Hchrome.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '60px',
   'margin-right': '2px',
   'float': 'right',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel1D5").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-5px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D5l").css({
   'background-image' : 'url("images/panel/Hchromel.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top':'-80px',
   'margin-left': '0px',
   'float': 'left',
   'height': '40px',
   'width': '30px'
                              });
    $("#frame3 #doorpanel3D5").css({
   'background-image' : 'url("images/panel/Hchrome.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top':'-80px',
   'margin-right': '0px',
   'float': 'right',
   'height': '40px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel1D6").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-160px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D6").css({
   'background-image' : 'url("images/panel/Hchrome.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-70px',
   'margin-right': '-17px',
   'float': 'right',
   'height': '25px',
   'width': '30px'
                              });
    
     $("#frame3 #doorpanel1D7").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-260px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D7").css({
   'background-image' : 'url("images/panel/Hchrome.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-105px',
   'margin-right': '-17px',
   'float': 'right',
   'height': '25px',
   'width': '30px'
                              });
    
        
    $("#frame3 #doorpanel1D8").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-40px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D8").css({
   'background-image' : 'url("images/panel/Hchrome.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-20px',
   'margin-right': '5px',
   'float': 'right',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel1D9").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-20px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D9").css({
   'background-image' : 'url("images/panel/Hchrome.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-8px',
   'margin-right': '5px',
   'float': 'right',
   'height': '25px',
   'width': '30px'
                              });
    
    $('div#displaydoor div div#beforecenter div#doorcenter4 table').css({'margin': '-4px auto', 'width': '100%'});
    $('div#displaydoor div div#beforecenter div#doorcenter4 div.glass').css({'margin': '0px auto', 'width': '35%', 'height':'60px', 'border-radius': '5px'});
});


$('#Hpanel3').on('click', function () {
    isRedOrBlue = "Hpanel3";
    // For identification, I'm adding border
    
    
     $('#frame3 #doorpanel3').empty();  
     $('#frame3 #doorpanel3D1').empty();  
     $('#frame3 #doorpanel3D2').empty(); 
     $('#frame3 #doorpanel3D3').empty();
     $('#frame3 #doorpanel3D4').empty(); 
     $('#frame3 #doorpanel3D5').empty();
     $('#frame3 #doorpanel3D6').empty(); 
     $('#frame3 #doorpanel3D7').empty(); 
     $('#frame3 #doorpanel3D8').empty();  
     $('#frame3 #doorpanel3D9').empty();
//$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    
    $("#frame3 #doorpanel1D4").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '20px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel2D4").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '2px auto',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel3D4").css({
   'background-image' : 'url("images/panel/Hwhite.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '10px',
   'margin-left': '5px',
   'height': '30px',
   'width': '30px',
   'float': 'right'
                              });
    
    $("#frame3 #doorpanel1D1").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '30px',
   'margin-right': '25%',
   'margin-left': '75%',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel2D1").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '2px auto',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel3D1").css({
   'background-image' : 'url("images/panel/Hwhite.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '60px',
   'margin-left': '90px',
   'height': '30px',
   'width': '30px'
                              });
    
    
             $("#frame3 #doorpanel1D2").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '35px auto',
   'margin-left': '75%',
   'margin-right': '25%',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D2").css({
   'background-image' : 'url("images/panel/Hwhite.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '120px',
   'margin-right': '-130px',
   'float': 'right',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel1D3").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '0px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D3").css({
   'background-image' : 'url("images/panel/Hwhite.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '60px',
   'margin-right': '2px',
   'float': 'right',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel1D5").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-5px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D5l").css({
   'background-image' : 'url("images/panel/Hwhitel.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top':'-80px',
   'margin-left': '0px',
   'float': 'left',
   'height': '40px',
   'width': '30px'
                              });
    $("#frame3 #doorpanel3D5").css({
   'background-image' : 'url("images/panel/Hwhite.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top':'-80px',
   'margin-right': '0px',
   'float': 'right',
   'height': '40px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel1D6").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-160px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D6").css({
   'background-image' : 'url("images/panel/Hwhite.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-70px',
   'margin-right': '-17px',
   'float': 'right',
   'height': '25px',
   'width': '30px'
                              });
    
     $("#frame3 #doorpanel1D7").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-260px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D7").css({
   'background-image' : 'url("images/panel/Hwhite.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-105px',
   'margin-right': '-17px',
   'float': 'right',
   'height': '25px',
   'width': '30px'
                              });
    
        
    $("#frame3 #doorpanel1D8").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-40px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D8").css({
   'background-image' : 'url("images/panel/Hwhite.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-20px',
   'margin-right': '5px',
   'float': 'right',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel1D9").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-20px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D9").css({
   'background-image' : 'url("images/panel/Hwhite.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-8px',
   'margin-right': '5px',
   'float': 'right',
   'height': '25px',
   'width': '30px'
                              });
    
    $('div#displaydoor div div#beforecenter div#doorcenter4 table').css({'margin': '-4px auto', 'width': '100%'});
    $('div#displaydoor div div#beforecenter div#doorcenter4 div.glass').css({'margin': '0px auto', 'width': '35%', 'height':'60px', 'border-radius': '5px'});
});



$('#Hpanel4').on('click', function () {
    isRedOrBlue = "Hpanel4";
    // For identification, I'm adding border
    
    
     $('#frame3 #doorpanel3').empty();  
     $('#frame3 #doorpanel3D1').empty();  
     $('#frame3 #doorpanel3D2').empty(); 
     $('#frame3 #doorpanel3D3').empty();
     $('#frame3 #doorpanel3D4').empty(); 
     $('#frame3 #doorpanel3D5').empty();
     $('#frame3 #doorpanel3D6').empty(); 
     $('#frame3 #doorpanel3D7').empty(); 
     $('#frame3 #doorpanel3D8').empty();  
     $('#frame3 #doorpanel3D9').empty();
//$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    
     $("#frame3 #doorpanel1D4").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '20px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel2D4").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '2px auto',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel3D4").css({
   'background-image' : 'url("images/panel/Hblack.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '10px',
   'margin-left': '5px',
   'height': '30px',
   'width': '30px',
   'float': 'right'
                              });
    
    $("#frame3 #doorpanel1D1").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '30px',
   'margin-right': '25%',
   'margin-left': '75%',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel2D1").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '2px auto',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel3D1").css({
   'background-image' : 'url("images/panel/Hblack.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '60px',
   'margin-left': '90px',
   'height': '30px',
   'width': '30px'
                              });
    
    
             $("#frame3 #doorpanel1D2").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '35px auto',
   'margin-left': '75%',
   'margin-right': '25%',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D2").css({
   'background-image' : 'url("images/panel/Hblack.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '120px',
   'margin-right': '-130px',
   'float': 'right',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel1D3").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '0px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D3").css({
   'background-image' : 'url("images/panel/Hblack.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '60px',
   'margin-right': '2px',
   'float': 'right',
   'height': '30px',
   'width': '30px'
                              });
    
    
    $("#frame3 #doorpanel1D5").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-5px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D5l").css({
   'background-image' : 'url("images/panel/Hblackl.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top':'-80px',
   'margin-left': '0px',
   'float': 'left',
   'height': '40px',
   'width': '30px'
                              });
    $("#frame3 #doorpanel3D5").css({
   'background-image' : 'url("images/panel/Hblack.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top':'-80px',
   'margin-right': '0px',
   'float': 'right',
   'height': '40px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel1D6").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-160px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D6").css({
   'background-image' : 'url("images/panel/Hblack.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-70px',
   'margin-right': '-17px',
   'float': 'right',
   'height': '25px',
   'width': '30px'
                              });
    
     $("#frame3 #doorpanel1D7").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-260px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D7").css({
   'background-image' : 'url("images/panel/Hblack.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-105px',
   'margin-right': '-17px',
   'float': 'right',
   'height': '25px',
   'width': '30px'
                              });
    
        
    $("#frame3 #doorpanel1D8").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-40px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D8").css({
   'background-image' : 'url("images/panel/Hblack.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-20px',
   'margin-right': '5px',
   'float': 'right',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel1D9").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-20px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D9").css({
   'background-image' : 'url("images/panel/Hblack.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-8px',
   'margin-right': '5px',
   'float': 'right',
   'height': '25px',
   'width': '30px'
                              });
    
    $('div#displaydoor div div#beforecenter div#doorcenter4 table').css({'margin': '-4px auto', 'width': '100%'});
    $('div#displaydoor div div#beforecenter div#doorcenter4 div.glass').css({'margin': '0px auto', 'width': '35%', 'height':'60px', 'border-radius': '5px'});
});



$('#Hpanel5').on('click', function () {
    isRedOrBlue = "Hpanel5";
    // For identification, I'm adding border
    
    
     $('#frame3 #doorpanel3').empty();  
     $('#frame3 #doorpanel3D1').empty();  
     $('#frame3 #doorpanel3D2').empty(); 
     $('#frame3 #doorpanel3D3').empty();
     $('#frame3 #doorpanel3D4').empty(); 
     $('#frame3 #doorpanel3D5').empty();
     $('#frame3 #doorpanel3D6').empty(); 
     $('#frame3 #doorpanel3D7').empty(); 
     $('#frame3 #doorpanel3D8').empty();  
     $('#frame3 #doorpanel3D9').empty();
//$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    
     $("#frame3 #doorpanel1D4").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '20px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel2D4").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '2px auto',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel3D4").css({
   'background-image' : 'none',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '10px',
   'margin-left': '5px',
   'height': '30px',
   'width': '30px',
   'float': 'right'
                              });
    
    $("#frame3 #doorpanel1D1").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '30px',
   'margin-right': '25%',
   'margin-left': '75%',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel2D1").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '2px auto',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel3D1").css({
   'background-image' : 'none',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '60px',
   'margin-left': '90px',
   'height': '30px',
   'width': '30px'
                              });
    
    
    $("#frame3 #doorpanel1D2").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '35px auto',
   'margin-left': '75%',
   'margin-right': '25%',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D2").css({
   'background-image' : 'none',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '120px',
   'margin-right': '-130px',
   'float': 'right',
   'height': '30px',
   'width': '30px'
                              });
    
    
    $("#frame3 #doorpanel1D3").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '0px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D3").css({
   'background-image' : 'none',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '60px',
   'margin-right': '2px',
   'float': 'right',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel1D5").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-5px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D5l").css({
   'background-image' : 'none',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top':'-80px',
   'margin-left': '0px',
   'float': 'left',
   'height': '40px',
   'width': '30px'
                              });
    $("#frame3 #doorpanel3D5").css({
   'background-image' : 'none',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top':'-80px',
   'margin-right': '0px',
   'float': 'right',
   'height': '40px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel1D6").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-160px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D6").css({
   'background-image' : 'none',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-70px',
   'margin-right': '-17px',
   'float': 'right',
   'height': '25px',
   'width': '30px'
                              });
    
     $("#frame3 #doorpanel1D7").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-260px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D7").css({
   'background-image' : 'none',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-105px',
   'margin-right': '-17px',
   'float': 'right',
   'height': '25px',
   'width': '30px'
                              });
    
        
    $("#frame3 #doorpanel1D8").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-40px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D8").css({
   'background-image' : 'none',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-20px',
   'margin-right': '5px',
   'float': 'right',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel1D9").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '-20px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel3D9").css({
   'background-image' : 'none',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '-8px',
   'margin-right': '5px',
   'float': 'right',
   'height': '25px',
   'width': '30px'
                              });
    
    $('div#displaydoor div div#beforecenter div#doorcenter4 table').css({'margin': '-4px auto', 'width': '100%'});
    $('div#displaydoor div div#beforecenter div#doorcenter4 div.glass').css({'margin': '0px auto', 'width': '35%', 'height':'60px', 'border-radius': '5px'});
});




$('#Kpanel1').on('click', function () {
    isRedOrBlue = "Kpanel1";
    // For identification, I'm adding border
    
    
     $('#frame3 #doorpanel2').empty();  
     $('#frame3 #doorpanel2D1').empty();  
     $('#frame3 #doorpanel2D2').empty(); 
     $('#frame3 #doorpanel2D3').empty();
     $('#frame3 #doorpanel2D4').empty(); 
     $('#frame3 #doorpanel2D5').empty();
     $('#frame3 #doorpanel2D6').empty(); 
     $('#frame3 #doorpanel2D7').empty(); 
     $('#frame3 #doorpanel2D8').empty();  
     $('#frame3 #doorpanel2D9').empty();
//$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    
     $("#frame3 #doorpanel1D4").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '20px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel2D4").css({
   'background-image' : 'url("images/panel/Kbrass.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '2px auto',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel3D4").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '10px',
   'margin-left': '5px',
   'height': '30px',
   'width': '30px',
   'float': 'right'
                              });
    
    
    $("#frame3 #doorpanel1D3").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '0px auto',
   'height': '15px',
   'width': '50px'
                              });
    
   $("#frame3 #doorpanel2D3").css({
   'background-image' : 'url("images/panel/Kbrass.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '2px auto',
   'height': '30px',
   'width': '30px'
                              });
    
     $("#frame3 #doorpanel3D3").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '60px',
   'margin-right': '2px',
   'float': 'right',
   'height': '30px',
   'width': '30px'
                              });
    
    $('div#displaydoor div div#beforecenter div#doorcenter4 table').css({'margin': '-4px auto', 'width': '100%'});
    $('div#displaydoor div div#beforecenter div#doorcenter4 div.glass').css({'margin': '0px auto', 'width': '35%', 'height':'60px', 'border-radius': '5px'});
});




$('#Kpanel2').on('click', function () {
    isRedOrBlue = "Kpanel1";
    // For identification, I'm adding border
    
    
     $('#frame3 #doorpanel2').empty();  
     $('#frame3 #doorpanel2D1').empty();  
     $('#frame3 #doorpanel2D2').empty(); 
     $('#frame3 #doorpanel2D3').empty();
     $('#frame3 #doorpanel2D4').empty(); 
     $('#frame3 #doorpanel2D5').empty();
     $('#frame3 #doorpanel2D6').empty(); 
     $('#frame3 #doorpanel2D7').empty(); 
     $('#frame3 #doorpanel2D8').empty();  
     $('#frame3 #doorpanel2D9').empty();
//$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    
     $("#frame3 #doorpanel1D4").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '20px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel2D4").css({
   'background-image' : 'url("images/panel/Kchrome.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '2px auto',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel3D4").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '10px',
   'margin-left': '5px',
   'height': '30px',
   'width': '30px'
                              });
    
    
    $("#frame3 #doorpanel1D3").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '0px auto',
   'height': '15px',
   'width': '50px'
                              });
    
   $("#frame3 #doorpanel2D3").css({
   'background-image' : 'url("images/panel/Kchrome.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '2px auto',
   'height': '30px',
   'width': '30px'
                              });
    
     $("#frame3 #doorpanel3D3").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '60px',
   'margin-right': '2px',
   'float': 'right',
   'height': '30px',
   'width': '30px'
                              });
    
    $('div#displaydoor div div#beforecenter div#doorcenter4 table').css({'margin': '-4px auto', 'width': '100%'});
    $('div#displaydoor div div#beforecenter div#doorcenter4 div.glass').css({'margin': '0px auto', 'width': '35%', 'height':'60px', 'border-radius': '5px'});
});




$('#Kpanel3').on('click', function () {
    isRedOrBlue = "Kpanel1";
    // For identification, I'm adding border
    
    
     $('#frame3 #doorpanel2').empty();  
     $('#frame3 #doorpanel2D1').empty();  
     $('#frame3 #doorpanel2D2').empty(); 
     $('#frame3 #doorpanel2D3').empty();
     $('#frame3 #doorpanel2D4').empty(); 
     $('#frame3 #doorpanel2D5').empty();
     $('#frame3 #doorpanel2D6').empty(); 
     $('#frame3 #doorpanel2D7').empty(); 
     $('#frame3 #doorpanel2D8').empty();  
     $('#frame3 #doorpanel2D9').empty();
//$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    
     $("#frame3 #doorpanel1D4").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '20px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel2D4").css({
   'background-image' : 'url("images/panel/Kwhite.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '2px auto',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel3D4").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '10px',
   'margin-left': '5px',
   'height': '30px',
   'width': '30px'
                              });
    
    
    $("#frame3 #doorpanel1D3").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '0px auto',
   'height': '15px',
   'width': '50px'
                              });
    
   $("#frame3 #doorpanel2D3").css({
   'background-image' : 'url("images/panel/Kwhite.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '2px auto',
   'height': '30px',
   'width': '30px'
                              });
    
     $("#frame3 #doorpanel3D3").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '60px',
   'margin-right': '2px',
   'float': 'right',
   'height': '30px',
   'width': '30px'
                              });
    
    $('div#displaydoor div div#beforecenter div#doorcenter4 table').css({'margin': '-4px auto', 'width': '100%'});
    $('div#displaydoor div div#beforecenter div#doorcenter4 div.glass').css({'margin': '0px auto', 'width': '35%', 'height':'60px', 'border-radius': '5px'});
});




$('#Kpanel4').on('click', function () {
    isRedOrBlue = "Kpanel1";
    // For identification, I'm adding border
    
    
     $('#frame3 #doorpanel2').empty();  
     $('#frame3 #doorpanel2D1').empty();  
     $('#frame3 #doorpanel2D2').empty(); 
     $('#frame3 #doorpanel2D3').empty();
     $('#frame3 #doorpanel2D4').empty(); 
     $('#frame3 #doorpanel2D5').empty();
     $('#frame3 #doorpanel2D6').empty(); 
     $('#frame3 #doorpanel2D7').empty(); 
     $('#frame3 #doorpanel2D8').empty();  
     $('#frame3 #doorpanel2D9').empty();
//$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    
     $("#frame3 #doorpanel1D4").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '20px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel2D4").css({
   'background-image' : 'url("images/panel/Kblack.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '2px auto',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel3D4").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '10px',
   'margin-left': '5px',
   'height': '30px',
   'width': '30px'
                              });
    
    
    $("#frame3 #doorpanel1D3").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '0px auto',
   'height': '15px',
   'width': '50px'
                              });
    
   $("#frame3 #doorpanel2D3").css({
   'background-image' : 'url("images/panel/Kblack.png")',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '2px auto',
   'height': '30px',
   'width': '30px'
                              });
    
     $("#frame3 #doorpanel3D3").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '60px',
   'margin-right': '2px',
   'float': 'right',
   'height': '30px',
   'width': '30px'
                              });
    
    $('div#displaydoor div div#beforecenter div#doorcenter4 table').css({'margin': '-4px auto', 'width': '100%'});
    $('div#displaydoor div div#beforecenter div#doorcenter4 div.glass').css({'margin': '0px auto', 'width': '35%', 'height':'60px', 'border-radius': '5px'});
});




$('#Kpanel5').on('click', function () {
    isRedOrBlue = "Kpanel5";
    // For identification, I'm adding border
    
    
     $('#frame3 #doorpanel2').empty();  
     $('#frame3 #doorpanel2D1').empty();  
     $('#frame3 #doorpanel2D2').empty(); 
     $('#frame3 #doorpanel2D3').empty();
     $('#frame3 #doorpanel2D4').empty(); 
     $('#frame3 #doorpanel2D5').empty();
     $('#frame3 #doorpanel2D6').empty(); 
     $('#frame3 #doorpanel2D7').empty(); 
     $('#frame3 #doorpanel2D8').empty();  
     $('#frame3 #doorpanel2D9').empty();
//$('#' + isRedOrBlue).clone().appendTo($('#frame3 .glass'));
    
     $("#frame3 #doorpanel1D4").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '20px auto',
   'height': '15px',
   'width': '50px'
                              });
    
     $("#frame3 #doorpanel2D4").css({
   'background-image' : 'none',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '2px auto',
   'height': '30px',
   'width': '30px'
                              });
    
    $("#frame3 #doorpanel3D4").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '10px',
   'margin-left': '5px',
   'height': '30px',
   'width': '30px',
   'float': 'right'
                              });
    
    
    
    $("#frame3 #doorpanel1D3").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '0px auto',
   'height': '15px',
   'width': '50px'
                              });
    
   $("#frame3 #doorpanel2D3").css({
   'background-image' : 'none',
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin': '2px auto',
   'height': '30px',
   'width': '30px'
                              });
    
     $("#frame3 #doorpanel3D3").css({
   'background-size' : '100% 100%',
   'background-repeat' : 'no-repeat',
   'margin-top': '60px',
   'margin-right': '2px',
   'float': 'right',
   'height': '30px',
   'width': '30px'
                              });
    
    $('div#displaydoor div div#beforecenter div#doorcenter4 table').css({'margin': '-4px auto', 'width': '100%'});
    $('div#displaydoor div div#beforecenter div#doorcenter4 div.glass').css({'margin': '0px auto', 'width': '35%', 'height':'60px', 'border-radius': '5px'});
});



